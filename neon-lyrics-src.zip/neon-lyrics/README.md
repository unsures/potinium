# Neon Lyrics

Glowing synced Spotify lyrics on your screen and floating in the world.
Press B in a world to open the song menu (press B again to close it).
Built for Minecraft 1.21.11 and 26.1.2 (Fabric + Fabric API).
