package com.neonlyrics;

import net.minecraft.client.gui.components.AbstractWidget;
import org.lwjgl.glfw.GLFW;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/** Lets the menu be dragged by its top bar. All widgets remember a "base" spot and are shifted by the shared offset. */
final class MenuDrag {
    static int offX;
    static int offY;
    static final int HEADER_H = 16;

    private final Map<AbstractWidget, int[]> base = new IdentityHashMap<>();
    private boolean dragging;
    private boolean wasDown;
    private int grabX, grabY;

    void trackAll(List<?> children) {
        base.clear();
        for (Object o : children) {
            if (o instanceof AbstractWidget w) base.put(w, new int[]{w.getX(), w.getY()});
        }
    }

    void setBaseY(AbstractWidget w, int y) {
        int[] b = base.get(w);
        if (b != null) b[1] = y;
        else base.put(w, new int[]{w.getX(), y});
    }

    int baseX(AbstractWidget w) {
        int[] b = base.get(w);
        return b != null ? b[0] : w.getX();
    }

    void apply() {
        for (Map.Entry<AbstractWidget, int[]> e : base.entrySet()) {
            e.getKey().setX(e.getValue()[0] + offX);
            e.getKey().setY(e.getValue()[1] + offY);
        }
    }

    /** Call once per frame with the mouse position in GUI coordinates. */
    void update(int mouseX, int mouseY, int screenW, int screenH) {
        boolean down = false;
        try {
            long win = GLFW.glfwGetCurrentContext();
            down = win != 0 && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        } catch (Throwable ignored) {
        }
        int left = screenW / 2 - 160 + offX;
        if (down && !wasDown && mouseX >= left && mouseX <= left + 320
                && mouseY >= offY && mouseY <= offY + HEADER_H) {
            dragging = true;
            grabX = mouseX - offX;
            grabY = mouseY - offY;
        }
        if (!down) dragging = false;
        if (dragging) {
            offX = Math.max(-screenW / 2, Math.min(screenW / 2, mouseX - grabX));
            offY = Math.max(-8, Math.min(screenH - 30, mouseY - grabY));
        }
        wasDown = down;
        apply();
    }
}
