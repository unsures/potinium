package com.neonlyrics;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Tap-friendly settings: every value has a [-] and [+] button (no sliders to drag). */
public class SettingsScreen extends Screen {
    private static final String[] TABS = {"World", "Screen", "Style", "Color", "Misc"};

    private final Screen parent;
    private int tab;
    private final List<List<AbstractWidget>> tabWidgets = new ArrayList<>();
    private final List<Runnable> updaters = new ArrayList<>();

    public SettingsScreen(Screen parent) {
        super(Component.literal("Potinium Settings"));
        this.parent = parent;
    }

    private Config c() {
        return NeonLyricsClient.CONFIG;
    }

    @Override
    protected void init() {
        tabWidgets.clear();
        updaters.clear();
        int cx = this.width / 2;

        int tw = 56;
        int tx = cx - (TABS.length * tw + (TABS.length - 1) * 4) / 2;
        for (int i = 0; i < TABS.length; i++) {
            final int n = i;
            this.addRenderableWidget(Button.builder(Component.literal(TABS[i]), b -> showTab(n))
                    .bounds(tx + i * (tw + 4), 16, tw, 20).build());
            tabWidgets.add(new ArrayList<>());
        }

        Config c = c();

        // ---- World
        toggle(0, 0, "World lyrics", () -> c.showWorld, v -> c.showWorld = v);
        stepper(0, 1, "Distance", () -> Math.round(c.distance) + " blocks",
                () -> c.distance = Math.max(3, c.distance - 5), () -> c.distance = Math.min(200, c.distance + 5));
        stepper(0, 2, "Height", () -> Math.round(c.height) + " blocks",
                () -> c.height = Math.max(-10, c.height - 5), () -> c.height = Math.min(150, c.height + 5));
        stepper(0, 3, "Size", () -> String.format("%.2fx", c.worldScale),
                () -> c.worldScale = Math.max(0.25f, c.worldScale - 0.25f), () -> c.worldScale = Math.min(10f, c.worldScale + 0.25f));
        toggle(0, 4, "Follow camera", () -> c.followCamera, v -> c.followCamera = v);
        addTo(0, Button.builder(Component.literal("Preset: Near"), b -> {
            c.distance = 8;
            c.height = 1;
            c.worldScale = 1f;
            refresh();
        }).bounds(cx - 120, rowY(5), 118, 20).build());
        addTo(0, Button.builder(Component.literal("Preset: Far in the sky"), b -> {
            c.distance = 90;
            c.height = 70;
            c.worldScale = 2.5f;
            refresh();
        }).bounds(cx + 2, rowY(5), 118, 20).build());

        // ---- Screen
        toggle(1, 0, "Screen lyrics", () -> c.showScreen, v -> c.showScreen = v);
        stepper(1, 1, "Size", () -> String.format("%.2fx", c.screenScale),
                () -> c.screenScale = Math.max(0.5f, c.screenScale - 0.25f), () -> c.screenScale = Math.min(6f, c.screenScale + 0.25f));
        stepper(1, 2, "Position", () -> c.screenYPercent + "% from top",
                () -> c.screenYPercent = Math.max(3, c.screenYPercent - 3), () -> c.screenYPercent = Math.min(95, c.screenYPercent + 3));

        // ---- Style
        stepper(2, 0, "Font", () -> LyricMath.FONT_NAMES[c.fontIndex],
                () -> c.fontIndex = (c.fontIndex + LyricMath.FONT_NAMES.length - 1) % LyricMath.FONT_NAMES.length,
                () -> c.fontIndex = (c.fontIndex + 1) % LyricMath.FONT_NAMES.length);
        stepper(2, 1, "Fade in", () -> c.fadeInMs + " ms",
                () -> c.fadeInMs = Math.max(0, c.fadeInMs - 50), () -> c.fadeInMs = Math.min(2000, c.fadeInMs + 50));
        stepper(2, 2, "Fade out", () -> c.fadeOutMs + " ms",
                () -> c.fadeOutMs = Math.max(0, c.fadeOutMs - 50), () -> c.fadeOutMs = Math.min(2000, c.fadeOutMs + 50));
        stepper(2, 3, "Timing", () -> (c.lyricOffsetMs > 0 ? "+" : "") + c.lyricOffsetMs + " ms",
                () -> c.lyricOffsetMs = Math.max(-5000, c.lyricOffsetMs - 100), () -> c.lyricOffsetMs = Math.min(5000, c.lyricOffsetMs + 100));

        // ---- Color
        stepper(3, 0, "Color", () -> LyricMath.COLOR_NAMES[c.colorIndex],
                () -> c.colorIndex = (c.colorIndex + LyricMath.COLOR_NAMES.length - 1) % LyricMath.COLOR_NAMES.length,
                () -> c.colorIndex = (c.colorIndex + 1) % LyricMath.COLOR_NAMES.length);
        stepper(3, 1, "Custom red", () -> String.valueOf(c.customR), () -> {
            c.customR = LyricMath.clamp255(c.customR - 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        }, () -> {
            c.customR = LyricMath.clamp255(c.customR + 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        });
        stepper(3, 2, "Custom green", () -> String.valueOf(c.customG), () -> {
            c.customG = LyricMath.clamp255(c.customG - 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        }, () -> {
            c.customG = LyricMath.clamp255(c.customG + 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        });
        stepper(3, 3, "Custom blue", () -> String.valueOf(c.customB), () -> {
            c.customB = LyricMath.clamp255(c.customB - 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        }, () -> {
            c.customB = LyricMath.clamp255(c.customB + 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        });

        // ---- Misc
        toggle(4, 0, "Open menu on join", () -> c.autoOpenOnJoin, v -> c.autoOpenOnJoin = v);
        addTo(4, Button.builder(Component.literal("Re-center lyrics (G)"), b -> LyricsHud.recenter())
                .bounds(cx - 120, rowY(1), 240, 20).build());
        addTo(4, Button.builder(Component.literal("Unlink Spotify"), b -> {
            SpotifyClient.get().logout();
            this.minecraft.setScreen(new SongMenuScreen());
        }).bounds(cx - 120, rowY(2), 240, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx - 60, this.height - 24, 120, 20).build());

        showTab(tab);
        refresh();
    }

    private int rowY(int row) {
        return 44 + row * 24;
    }

    private void addTo(int t, AbstractWidget w) {
        this.addRenderableWidget(w);
        tabWidgets.get(t).add(w);
    }

    private void toggle(int t, int row, String label, Supplier<Boolean> get, java.util.function.Consumer<Boolean> set) {
        Button b = Button.builder(Component.empty(), btn -> {
            set.accept(!get.get());
            refresh();
        }).bounds(this.width / 2 - 120, rowY(row), 240, 20).build();
        addTo(t, b);
        updaters.add(() -> b.setMessage(Component.literal(label + ": " + (get.get() ? "ON" : "OFF"))));
    }

    private void stepper(int t, int row, String label, Supplier<String> value, Runnable dec, Runnable inc) {
        int x = this.width / 2 - 120;
        int y = rowY(row);
        Button mid = Button.builder(Component.empty(), b -> {
        }).bounds(x + 28, y, 184, 20).build();
        addTo(t, Button.builder(Component.literal("-"), b -> {
            dec.run();
            refresh();
        }).bounds(x, y, 24, 20).build());
        addTo(t, mid);
        addTo(t, Button.builder(Component.literal("+"), b -> {
            inc.run();
            refresh();
        }).bounds(x + 216, y, 24, 20).build());
        updaters.add(() -> mid.setMessage(Component.literal(label + ": " + value.get())));
    }

    private void refresh() {
        for (Runnable r : updaters) r.run();
        c().save();
    }

    private void showTab(int t) {
        tab = t;
        for (int i = 0; i < tabWidgets.size(); i++) {
            for (AbstractWidget w : tabWidgets.get(i)) w.visible = i == t;
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        String hint = switch (tab) {
            case 0 -> "Far + high = lyrics up in the sky. Near + low = close to you.";
            case 1 -> "Lyrics flat on your screen, always readable.";
            case 2 -> "Fade in/out controls how lyric lines appear and disappear.";
            case 3 -> "Pick a color, or use the Custom red/green/blue buttons.";
            default -> "Press B (or Close) to leave the song menu.";
        };
        g.drawString(this.font, hint, this.width / 2 - this.font.width(hint) / 2, 4, 0xFFFFFFFF, true);
        LyricsHud.drawSaturn(g, this.width / 2 - 150, this.height - 30, 1);
        g.drawString(this.font, "POTINIUM", this.width / 2 - 126, this.height - 24, 0xFFFFFFFF, true);
    }

    @Override
    public void onClose() {
        c().save();
        this.minecraft.setScreen(parent);
    }
}
