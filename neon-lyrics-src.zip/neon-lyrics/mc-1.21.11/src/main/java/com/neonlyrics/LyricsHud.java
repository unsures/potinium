package com.neonlyrics;

import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Draws the lyrics: a rounded karaoke bar (or neon text) on the screen, and "in the world" lyrics, either
 * in front of you or as big word groups scattered near you that stay fixed in the world.
 */
public final class LyricsHud {
    private LyricsHud() {
    }

    private static float anchorYaw;
    private static boolean anchorInit;
    private static long lastNanos;
    private static final Random RND = new Random();

    // scatter: one entry per word group of the current line
    private record Group(String text, float yaw, float pitch, float dist, float roll, float sx, float appear) {
    }

    private static List<Group> groups = new ArrayList<>();
    private static int lineIdx = -9;
    private static String lineTrack = "";

    public static void recenter() {
        anchorInit = false;
        lineIdx = -9;
    }

    public static void render(GuiGraphics g, DeltaTracker tracker) {
        Config cfg = NeonLyricsClient.CONFIG;
        Minecraft mc = Minecraft.getInstance();
        if (cfg == null || mc.player == null) return;
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        if (mc.screen instanceof SongMenuScreen || mc.screen instanceof SettingsScreen) drawPanel(g, sw, sh);
        if (mc.options.hideGui) return;
        if (!cfg.showScreen && !cfg.showWorld) return;

        PlaybackState st = SpotifyClient.get().state();
        if (st.track() == null) return;

        List<LyricsService.Line> lines = NeonLyricsClient.LYRICS.lines();
        long pos = (long) (st.positionMs() * cfg.lyricSpeed) + cfg.lyricOffsetMs;
        LyricMath.Frame f;
        boolean statusOnly = false;
        if (lines.isEmpty()) {
            String s = NeonLyricsClient.LYRICS.status();
            f = new LyricMath.Frame(s, 0.7f, 0.7f, -1, 0, 1000);
            statusOnly = true;
        } else {
            long songLen = (long) (st.track().durationMs() * cfg.lyricSpeed);
            f = LyricMath.frame(lines, pos, cfg, songLen);
        }
        boolean hasText = f.text() != null && !f.text().isBlank();

        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0.016f : Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        float timeSec = now / 1e9f;
        int rgb = LyricMath.color(cfg, timeSec);
        Font font = mc.font;

        float pt = tracker.getGameTimeDeltaPartialTick(false);
        float yaw = mc.player.getViewYRot(pt);
        float pitch = mc.player.getViewXRot(pt);

        // a new line -> decide where its word groups appear
        String tid = st.track().id();
        if (f.index() != lineIdx || !tid.equals(lineTrack)) {
            lineIdx = f.index();
            lineTrack = tid;
            groups = hasText ? makeGroups(f.text(), yaw, cfg) : new ArrayList<>();
        }

        // ---- on the screen
        if (cfg.showScreen) {
            if (cfg.screenStyle == 0) {
                drawPill(g, font, f, pos, cfg, sw, sh, rgb, timeSec, st.playing(), hasText);
            } else if (hasText && f.alpha() >= 0.02f) {
                drawLine(g, font, f, pos, cfg, statusOnly ? 0 : cfg.animation, sw / 2f,
                        sh * (cfg.screenYPercent / 100f) + 10, cfg.screenScale, 0f, rgb, timeSec);
            }
        }

        // ---- in the world
        if (!cfg.showWorld || !hasText) return;
        int fov = mc.options.fov().get();

        if (cfg.placement == 1 && !statusOnly) {
            long dur = Math.max(1, f.endMs() - f.startMs());
            for (Group gr : groups) {
                long appearAt = f.startMs() + (long) (gr.appear() * dur * 0.55f);
                if (pos < appearAt) continue;
                float pop = Mth.clamp((pos - appearAt) / 260f, 0f, 1f);
                float a = Math.min(f.outAlpha(), pop);
                if (a < 0.03f) continue;
                double ya = Math.toRadians(gr.yaw()), pa = Math.toRadians(gr.pitch());
                double dx = -Math.sin(ya) * Math.cos(pa) * gr.dist();
                double dy = -Math.sin(pa) * gr.dist();
                double dz = Math.cos(ya) * Math.cos(pa) * gr.dist();
                float[] p = LyricMath.project(dx, dy, dz, yaw, pitch, fov, sw, sh);
                if (p == null) continue;
                float bpp = 0.025f * cfg.scatterScale * (1f + gr.dist() / 8f);
                float scale = Mth.clamp(bpp * p[2], 0.2f, 16f) * (0.6f + 0.4f * (1f - (1f - pop) * (1f - pop)));
                drawScatterWord(g, font, gr, cfg, p[0], p[1], scale, rgb, a);
            }
            return;
        }

        if (f.alpha() < 0.02f) return;
        if (!anchorInit) {
            anchorYaw = yaw;
            anchorInit = true;
        } else if (cfg.followCamera) {
            float diff = Mth.wrapDegrees(yaw - anchorYaw);
            anchorYaw += diff * (1f - (float) Math.pow(0.02, dt));
        }
        double a = Math.toRadians(anchorYaw);
        float dist = cfg.distance;
        float[] p = LyricMath.project(-Math.sin(a) * dist, cfg.height, Math.cos(a) * dist, yaw, pitch, fov, sw, sh);
        if (p != null) {
            float bpp = 0.025f * cfg.worldScale * (1f + dist / 8f);
            float scale = Mth.clamp(bpp * p[2], 0.15f, 14f);
            float roll = cfg.rotate ? (float) Math.toRadians(-LyricMath.tiltDeg(cfg) * 0.5f) : 0f;
            drawLine(g, font, f, pos, cfg, statusOnly ? 0 : cfg.animation, p[0], p[1], scale, roll, rgb, timeSec);
        }
    }

    // ------------------------------------------------------------------ scatter

    private static List<Group> makeGroups(String text, float viewYaw, Config cfg) {
        String t = cfg.fontIndex == 7 ? text : text.toUpperCase();
        List<String> parts = LyricMath.groups(t);
        int n = parts.size();
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < n; i++) slots.add(i);
        Collections.shuffle(slots, RND);
        float spread = cfg.spread;
        float tilt = LyricMath.tiltDeg(cfg) * 1.3f;
        List<Group> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            float slot = (slots.get(i) + 0.5f) / n;
            float yaw = viewYaw + (-spread + slot * 2f * spread) + (RND.nextFloat() - 0.5f) * (spread / n);
            float elev = -4f + RND.nextFloat() * 30f;
            float dist = cfg.scatterDistance * (0.85f + RND.nextFloat() * 0.35f);
            float roll = cfg.rotate ? (RND.nextFloat() * 2f - 1f) * tilt : 0f;
            float sx = 0.85f + RND.nextFloat() * 0.15f;
            out.add(new Group(parts.get(i), yaw, -elev, dist, (float) Math.toRadians(roll), sx, i / (float) Math.max(1, n)));
        }
        return out;
    }

    private static void drawScatterWord(GuiGraphics g, Font font, Group gr, Config cfg, float cx, float cy,
                                        float scale, int rgb, float alpha) {
        MutableComponent comp = styled(gr.text(), cfg, true);
        int w = font.width(comp);
        int x0 = -w / 2;
        int y0 = -font.lineHeight / 2;
        g.pose().pushMatrix();
        g.pose().translate(cx, cy);
        if (gr.roll() != 0f) g.pose().rotate(gr.roll());
        g.pose().scale(scale * gr.sx(), scale);
        int dark = LyricMath.mix(rgb, 0x000000, 0.6f);
        for (int k = 5; k >= 1; k--) { // the "3D" depth behind the letters
            g.drawString(font, comp, x0 + k, y0 + k, LyricMath.argb(alpha * 0.9f, dark), false);
        }
        int glow = LyricMath.argb(alpha * 0.2f, rgb);
        for (int[] d : DIRS) g.drawString(font, comp, x0 + d[0], y0 + d[1], glow, false);
        g.drawString(font, comp, x0, y0, LyricMath.argb(alpha, LyricMath.mix(rgb, 0xFFFFFF, 0.18f)), false);
        g.pose().popMatrix();
    }

    // ------------------------------------------------------------------ rounded karaoke bar

    private static void drawPill(GuiGraphics g, Font font, LyricMath.Frame f, long pos, Config cfg,
                                 int sw, int sh, int rgb, float t, boolean playing, boolean hasText) {
        float alpha = hasText ? f.alpha() : 0f;
        String text = hasText ? LyricMath.transform(f.text(), cfg.fontIndex) : "";
        MutableComponent comp = styled(text, cfg, false);
        int tw = font.width(comp);
        int iconW = 20, eqW = 22, pad = 6;
        int innerW = Math.max(tw, 36);
        int pw = iconW + innerW + eqW + pad;
        float s = cfg.screenScale;
        float maxW = sw * 0.85f;
        if (pw * s > maxW) s = maxW / pw;

        float cx = sw / 2f;
        float top = sh * (cfg.screenYPercent / 100f);
        g.pose().pushMatrix();
        g.pose().translate(cx, top);
        g.pose().scale(s, s);
        int x0 = -pw / 2;
        int ph = 18;

        Ui.roundRect(g, x0 - 1, -1, pw + 2, ph + 2, 10, LyricMath.argb(0.35f, rgb));   // soft coloured edge
        Ui.roundRect(g, x0, 0, pw, ph, 9, LyricMath.argb(0.92f, 0x14121F));            // dark rounded bar

        int dcx = x0 + 11, dcy = 9;                                                   // little record icon
        Ui.circle(g, dcx, dcy, 6, LyricMath.argb(1f, rgb));
        Ui.circle(g, dcx, dcy, 3, LyricMath.argb(1f, 0x14121F));
        Ui.circle(g, dcx, dcy, 1, 0xFFFFFFFF);

        if (hasText && alpha >= 0.03f) {
            int tx = x0 + iconW + (innerW - tw) / 2;
            int ty = (ph - font.lineHeight) / 2 + 1;
            int len = text.length();
            long dur = Math.max(1, f.endMs() - f.startMs());
            float span = Math.max(300f, dur * 0.85f);
            float frac = Mth.clamp((pos - f.startMs()) / span, 0f, 1f);
            float exact = len * frac;
            int n = Math.min(len, (int) exact);
            float partial = exact - n;
            float hx = font.width(styled(text.substring(0, n), cfg, false));
            if (n < len) {
                float next = font.width(styled(text.substring(0, n + 1), cfg, false));
                hx += (next - hx) * partial;
            }
            if (hx > 0.5f) { // the sung part gets a rounded highlight
                Ui.roundRect(g, tx - 2, 2, Math.round(hx) + 4, ph - 4, 5, LyricMath.argb(0.95f * alpha, rgb));
            }
            g.drawString(font, comp, tx, ty, LyricMath.argb(alpha, 0xC9C9DA), false);
            if (n > 0) {
                g.drawString(font, styled(text.substring(0, n), cfg, false), tx, ty,
                        LyricMath.argb(alpha, 0xFFFFFF), false);
            }
        }

        int ex = x0 + pw - eqW + 3;                                                    // equalizer bars
        float spd = LyricMath.speedMul(cfg);
        for (int i = 0; i < 4; i++) {
            int h = playing ? 3 + (int) (Math.abs(Math.sin(t * 5.5f * spd + i * 1.9f)) * 7) : 3;
            g.fill(ex + i * 4, 13 - h, ex + i * 4 + 2, 13, LyricMath.argb(1f, rgb));
        }
        g.pose().popMatrix();
    }

    // ------------------------------------------------------------------ neon text

    private static MutableComponent styled(String s, Config cfg, boolean forceBold) {
        MutableComponent c = Component.literal(s);
        if (forceBold || LyricMath.bold(cfg.fontIndex)) c = c.withStyle(ChatFormatting.BOLD);
        if (LyricMath.italic(cfg.fontIndex)) c = c.withStyle(ChatFormatting.ITALIC);
        if (LyricMath.underline(cfg.fontIndex)) c = c.withStyle(ChatFormatting.UNDERLINE);
        if (cfg.fontIndex == 7) c = FontSupport.script(c);
        return c;
    }

    private static void drawLine(GuiGraphics g, Font font, LyricMath.Frame f, long pos, Config cfg, int anim,
                                 float cx, float cy, float scale, float rollRad, int rgb, float t) {
        float spd = LyricMath.speedMul(cfg);
        float amp = LyricMath.ampMul(cfg);
        float glow = LyricMath.glowMul(cfg);
        String shown = LyricMath.transform(f.text(), cfg.fontIndex);
        int len = shown.length();
        float alpha = f.alpha();

        if (cfg.intensity == 1) { // Hype: every line pops in
            long el = pos - f.startMs();
            if (el >= 0 && el < 300) scale *= 1f + 0.2f * (1f - el / 300f);
        }

        g.pose().pushMatrix();
        g.pose().translate(cx, cy);
        if (rollRad != 0f) g.pose().rotate(rollRad);
        g.pose().scale(scale, scale);

        int fullW = font.width(styled(shown, cfg, false));
        int x0 = -fullW / 2;
        int y0 = -font.lineHeight / 2;
        long dur = Math.max(1, f.endMs() - f.startMs());
        float elapsed = pos - f.startMs();

        switch (anim) {
            case 1 -> { // Typewriter
                float revealMs = Mth.clamp(len * 65f / spd, 350f, Math.max(400f, dur * 0.75f));
                float frac = Mth.clamp(elapsed / revealMs, 0f, 1f);
                int n = Math.min(len, (int) Math.ceil(len * frac));
                float a = f.outAlpha();
                if (n > 0) glowText(g, font, styled(shown.substring(0, n), cfg, false), x0, y0, rgb, a, glow, true);
                if (frac < 1f && ((long) (t * 2.5f * spd)) % 2 == 0) {
                    int cxp = x0 + font.width(styled(shown.substring(0, n), cfg, false));
                    glowText(g, font, styled("|", cfg, false), cxp, y0, rgb, a, glow, false);
                }
            }
            case 2 -> { // Wave
                for (int i = 0; i < len; i++) {
                    String ch = shown.substring(i, i + 1);
                    if (ch.isBlank()) continue;
                    int cxp = x0 + font.width(styled(shown.substring(0, i), cfg, false));
                    int dy = Math.round((float) Math.sin(t * 3.4f * spd + i * 0.55f) * 2.4f * amp);
                    glowText(g, font, styled(ch, cfg, false), cxp, y0 + dy, rgb, alpha, glow, false);
                }
            }
            case 3 -> { // Karaoke: the line lights up as it is sung
                float span = Math.max(300f, dur * 0.85f);
                float frac = Mth.clamp(elapsed / span, 0f, 1f);
                int n = (int) (len * frac);
                int dim = LyricMath.mix(rgb, 0x808090, 0.65f);
                glowText(g, font, styled(shown, cfg, false), x0, y0, dim, alpha * 0.8f, glow * 0.6f, false);
                if (n > 0) glowText(g, font, styled(shown.substring(0, n), cfg, false), x0, y0, rgb, alpha, glow, true);
            }
            default -> glowText(g, font, styled(shown, cfg, false), x0, y0, rgb, alpha, glow, true);
        }
        g.pose().popMatrix();
    }

    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};

    private static void glowText(GuiGraphics g, Font font, Component text, int x, int y, int rgb,
                                 float alpha, float glow, boolean full) {
        if (alpha < 0.03f) return;
        int halo1 = LyricMath.argb(alpha * 0.28f * glow, rgb);
        if (full) {
            int halo2 = LyricMath.argb(alpha * 0.12f * glow, rgb);
            for (int[] d : DIRS) g.drawString(font, text, x + d[0] * 2, y + d[1] * 2, halo2, false);
        }
        for (int[] d : DIRS) g.drawString(font, text, x + d[0], y + d[1], halo1, false);
        g.drawString(font, text, x, y, LyricMath.argb(alpha, LyricMath.mix(rgb, 0xFFFFFF, 0.6f)), false);
    }

    // ------------------------------------------------------------------ menu look

    /** Dark, rounded, see-through menu panel (drawn under the menu so the game's blur softens it). */
    public static void drawPanel(GuiGraphics g, int sw, int sh) {
        int x1 = sw / 2 - 160 + MenuDrag.offX;
        int y1 = MenuDrag.offY + 2;
        int w = 320;
        int h = sh - 4;
        for (int i = 6; i >= 1; i--) {
            Ui.roundRect(g, x1 - i, y1 - i, w + 2 * i, h + 2 * i, 11 + i, LyricMath.argb(0.04f, 0x8B7BFF));
        }
        Ui.roundRect(g, x1 - 1, y1 - 1, w + 2, h + 2, 11, LyricMath.argb(0.75f, 0x4B4590));
        Ui.roundRect(g, x1, y1, w, h, 10, LyricMath.argb(0.88f, 0x0F0E24));
        if (MenuDrag.cards) {
            int cx = x1 + 6;
            Ui.roundRect(g, cx, MenuDrag.cardList1 + MenuDrag.offY, 308, MenuDrag.cardList2 - MenuDrag.cardList1, 7,
                    LyricMath.argb(0.7f, 0x1C1A3A));
            if (MenuDrag.cardNow1 >= 0) {
                Ui.roundRect(g, cx, MenuDrag.cardNow1 + MenuDrag.offY, 308, 36, 7, LyricMath.argb(0.85f, 0x1C1A3A));
            }
        }
    }

    private static int[][] saturn;

    private static int[][] saturnGrid() {
        if (saturn != null) return saturn;
        int w = 19, h = 13;
        int[][] gr = new int[h][w];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if ((x - 9) * (x - 9) + (y - 6) * (y - 6) <= 15) gr[y][x] = 1;
            }
        }
        double phi = Math.toRadians(20), cp = Math.cos(phi), sp = Math.sin(phi);
        for (int i = 0; i < 720; i++) {
            double t = i * 2 * Math.PI / 720;
            double a = 8.7 * Math.cos(t), b = 2.6 * Math.sin(t);
            int xi = (int) Math.round(9 + a * cp - b * sp);
            int yi = (int) Math.round(6 - (a * sp + b * cp));
            if (xi < 0 || xi >= w || yi < 0 || yi >= h) continue;
            if (gr[yi][xi] == 1) {
                if (Math.sin(t) < 0) gr[yi][xi] = 2;
            } else {
                gr[yi][xi] = 1;
            }
        }
        saturn = gr;
        return gr;
    }

    /** A small Saturn made of pixels (white with a lavender ring so it shows on the dark menu). */
    public static void drawSaturn(GuiGraphics g, int x0, int y0, int px) {
        int[][] gr = saturnGrid();
        for (int y = 0; y < gr.length; y++) {
            for (int x = 0; x < gr[y].length; x++) {
                if (gr[y][x] == 0) continue;
                int col = gr[y][x] == 1 ? 0xFFFFFFFF : 0xFFB69CE6;
                g.fill(x0 + x * px, y0 + y * px, x0 + (x + 1) * px, y0 + (y + 1) * px, col);
            }
        }
    }
}
