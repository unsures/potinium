package com.neonlyrics;

import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;

import java.util.List;
import java.util.Random;

/**
 * Draws the lyrics in two places: flat on the screen, and "in the world" (a 3D position projected onto
 * the screen). In "Scatter" placement every new line appears somewhere else around you and stays fixed
 * in the world, so turning your camera does not drag it along.
 */
public final class LyricsHud {
    private LyricsHud() {
    }

    private static float anchorYaw;
    private static boolean anchorInit;
    private static long lastNanos;

    // per-line random placement
    private static final Random RND = new Random();
    private static int lineIdx = -9;
    private static String lineTrack = "";
    private static float sYaw, sPitch, sDist, sRoll;

    public static void recenter() {
        anchorInit = false;
        lineIdx = -9;
    }

    public static void render(GuiGraphics g, DeltaTracker tracker) {
        Config cfg = NeonLyricsClient.CONFIG;
        Minecraft mc = Minecraft.getInstance();
        if (cfg == null || mc.player == null) return;
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        // The menus sit on a dark glass panel. It is drawn here, underneath the menu, so the game's own
        // menu blur softens it into a blurry see-through background.
        if (mc.screen instanceof SongMenuScreen || mc.screen instanceof SettingsScreen) drawPanel(g, sw, sh);
        if (mc.options.hideGui) return;
        if (!cfg.showScreen && !cfg.showWorld) return;

        PlaybackState st = SpotifyClient.get().state();
        if (st.track() == null) return;

        List<LyricsService.Line> lines = NeonLyricsClient.LYRICS.lines();
        long pos = (long) (st.positionMs() * cfg.lyricSpeed) + cfg.lyricOffsetMs;
        LyricMath.Frame f;
        boolean statusOnly = false;
        if (lines.isEmpty()) {
            String s = NeonLyricsClient.LYRICS.status();
            f = new LyricMath.Frame(s, 0.7f, 0.7f, -1, 0, 1000);
            statusOnly = true;
        } else {
            long songLen = (long) (st.track().durationMs() * cfg.lyricSpeed);
            f = LyricMath.frame(lines, pos, cfg, songLen);
        }
        if (f.text() == null || f.text().isBlank() || f.alpha() < 0.02f) return;

        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0.016f : Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        float timeSec = now / 1e9f;
        int rgb = LyricMath.color(cfg, timeSec);
        Font font = mc.font;

        float pt = tracker.getGameTimeDeltaPartialTick(false);
        float yaw = mc.player.getViewYRot(pt);
        float pitch = mc.player.getViewXRot(pt);

        // a new line -> choose where it appears and how it tilts
        String tid = st.track().id();
        if (f.index() != lineIdx || !tid.equals(lineTrack)) {
            lineIdx = f.index();
            lineTrack = tid;
            float spread = cfg.spread;
            sYaw = yaw + (RND.nextFloat() * 2f - 1f) * spread;
            float elev = -12f + RND.nextFloat() * 40f + (float) Math.toDegrees(Math.atan2(cfg.height, cfg.distance));
            sPitch = -Mth.clamp(elev, -70f, 70f);
            sDist = cfg.distance * (0.8f + RND.nextFloat() * 0.45f);
            float tilt = LyricMath.tiltDeg(cfg);
            sRoll = (RND.nextFloat() * 2f - 1f) * tilt;
        }
        float roll = cfg.rotate ? (float) Math.toRadians(sRoll) : 0f;
        int animMode = statusOnly ? 0 : cfg.animation;

        // ---- on the screen
        if (cfg.showScreen) {
            drawLine(g, font, f, pos, cfg, animMode, sw / 2f, sh * (cfg.screenYPercent / 100f),
                    cfg.screenScale, roll * 0.5f, rgb, timeSec);
        }

        // ---- in the world
        if (cfg.showWorld) {
            double dx, dy, dz;
            float dist;
            if (cfg.placement == 1) {
                double ya = Math.toRadians(sYaw), pa = Math.toRadians(sPitch);
                dist = sDist;
                dx = -Math.sin(ya) * Math.cos(pa) * dist;
                dy = -Math.sin(pa) * dist;
                dz = Math.cos(ya) * Math.cos(pa) * dist;
            } else {
                if (!anchorInit) {
                    anchorYaw = yaw;
                    anchorInit = true;
                } else if (cfg.followCamera) {
                    float diff = Mth.wrapDegrees(yaw - anchorYaw);
                    anchorYaw += diff * (1f - (float) Math.pow(0.02, dt));
                }
                double a = Math.toRadians(anchorYaw);
                dist = cfg.distance;
                dx = -Math.sin(a) * dist;
                dy = cfg.height;
                dz = Math.cos(a) * dist;
            }
            float[] p = LyricMath.project(dx, dy, dz, yaw, pitch, mc.options.fov().get(), sw, sh);
            if (p != null) {
                float blocksPerPixel = 0.025f * cfg.worldScale * (1f + dist / 8f);
                float scale = Mth.clamp(blocksPerPixel * p[2], 0.15f, 14f);
                drawLine(g, font, f, pos, cfg, animMode, p[0], p[1], scale, roll, rgb, timeSec);
            }
        }
    }

    // ------------------------------------------------------------------ drawing a line

    private static MutableComponent styled(String s, Config cfg) {
        MutableComponent c = Component.literal(s);
        if (LyricMath.bold(cfg.fontIndex)) c = c.withStyle(ChatFormatting.BOLD);
        if (LyricMath.italic(cfg.fontIndex)) c = c.withStyle(ChatFormatting.ITALIC);
        if (LyricMath.underline(cfg.fontIndex)) c = c.withStyle(ChatFormatting.UNDERLINE);
        return c;
    }

    private static void drawLine(GuiGraphics g, Font font, LyricMath.Frame f, long pos, Config cfg, int anim,
                                 float cx, float cy, float scale, float rollRad, int rgb, float t) {
        float spd = LyricMath.speedMul(cfg);
        float amp = LyricMath.ampMul(cfg);
        float glow = LyricMath.glowMul(cfg);
        String shown = LyricMath.transform(f.text(), cfg.fontIndex);
        int len = shown.length();
        float alpha = f.alpha();

        if (cfg.intensity == 1) { // Hype: every line pops in
            long el = pos - f.startMs();
            if (el >= 0 && el < 300) scale *= 1f + 0.2f * (1f - el / 300f);
        }

        g.pose().pushMatrix();
        g.pose().translate(cx, cy);
        if (rollRad != 0f) g.pose().rotate(rollRad);
        g.pose().scale(scale, scale);

        int fullW = font.width(styled(shown, cfg));
        int x0 = -fullW / 2;
        int y0 = -font.lineHeight / 2;
        long dur = Math.max(1, f.endMs() - f.startMs());
        float elapsed = pos - f.startMs();

        switch (anim) {
            case 1 -> { // Typewriter
                float revealMs = Mth.clamp(len * 65f / spd, 350f, Math.max(400f, dur * 0.75f));
                float frac = Mth.clamp(elapsed / revealMs, 0f, 1f);
                int n = Math.min(len, (int) Math.ceil(len * frac));
                float a = f.outAlpha();
                if (n > 0) glowText(g, font, styled(shown.substring(0, n), cfg), x0, y0, rgb, a, glow, true);
                if (frac < 1f && ((long) (t * 2.5f * spd)) % 2 == 0) {
                    int cxp = x0 + font.width(styled(shown.substring(0, n), cfg));
                    glowText(g, font, styled("|", cfg), cxp, y0, rgb, a, glow, false);
                }
            }
            case 2 -> { // Wave
                for (int i = 0; i < len; i++) {
                    String ch = shown.substring(i, i + 1);
                    if (ch.isBlank()) continue;
                    int cxp = x0 + font.width(styled(shown.substring(0, i), cfg));
                    int dy = Math.round((float) Math.sin(t * 3.4f * spd + i * 0.55f) * 2.4f * amp);
                    glowText(g, font, styled(ch, cfg), cxp, y0 + dy, rgb, alpha, glow, false);
                }
            }
            case 3 -> { // Karaoke: the line lights up as it is sung
                float span = Math.max(300f, dur * 0.85f);
                float frac = Mth.clamp(elapsed / span, 0f, 1f);
                int n = (int) (len * frac);
                int dim = LyricMath.mix(rgb, 0x808090, 0.65f);
                glowText(g, font, styled(shown, cfg), x0, y0, dim, alpha * 0.8f, glow * 0.6f, false);
                if (n > 0) glowText(g, font, styled(shown.substring(0, n), cfg), x0, y0, rgb, alpha, glow, true);
            }
            default -> glowText(g, font, styled(shown, cfg), x0, y0, rgb, alpha, glow, true);
        }
        g.pose().popMatrix();
    }

    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};

    private static void glowText(GuiGraphics g, Font font, Component text, int x, int y, int rgb,
                                 float alpha, float glow, boolean full) {
        if (alpha < 0.02f) return;
        int halo1 = LyricMath.argb(alpha * 0.28f * glow, rgb);
        if (full) {
            int halo2 = LyricMath.argb(alpha * 0.12f * glow, rgb);
            for (int[] d : DIRS) g.drawString(font, text, x + d[0] * 2, y + d[1] * 2, halo2, false);
        }
        for (int[] d : DIRS) g.drawString(font, text, x + d[0], y + d[1], halo1, false);
        g.drawString(font, text, x, y, LyricMath.argb(alpha, LyricMath.mix(rgb, 0xFFFFFF, 0.6f)), false);
    }

    // ------------------------------------------------------------------ menu look

    public static void drawPanel(GuiGraphics g, int sw, int sh) {
        int x1 = sw / 2 - 160 + MenuDrag.offX;
        int x2 = x1 + 320;
        int y1 = MenuDrag.offY;
        int y2 = y1 + sh;
        for (int i = 10; i >= 1; i--) {
            g.fill(x1 - i, y1, x2 + i, y2, LyricMath.argb(0.05f, 0xB69CE6)); // soft lavender glow edge
        }
        g.fill(x1, y1, x2, y2, LyricMath.argb(0.82f, 0x121212));              // dark glass
        g.fill(x1, y1, x2, y1 + 16, LyricMath.argb(0.9f, 0x181818));          // header bar
        g.fill(x1, y1 + 16, x2, y1 + 17, LyricMath.argb(1f, 0x1DB954));       // green accent line
    }

    private static int[][] saturn;

    private static int[][] saturnGrid() {
        if (saturn != null) return saturn;
        int w = 19, h = 13;
        int[][] gr = new int[h][w];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if ((x - 9) * (x - 9) + (y - 6) * (y - 6) <= 15) gr[y][x] = 1;
            }
        }
        double phi = Math.toRadians(20), cp = Math.cos(phi), sp = Math.sin(phi);
        for (int i = 0; i < 720; i++) {
            double t = i * 2 * Math.PI / 720;
            double a = 8.7 * Math.cos(t), b = 2.6 * Math.sin(t);
            int xi = (int) Math.round(9 + a * cp - b * sp);
            int yi = (int) Math.round(6 - (a * sp + b * cp));
            if (xi < 0 || xi >= w || yi < 0 || yi >= h) continue;
            if (gr[yi][xi] == 1) {
                if (Math.sin(t) < 0) gr[yi][xi] = 2;
            } else {
                gr[yi][xi] = 1;
            }
        }
        saturn = gr;
        return gr;
    }

    /** A small Saturn made of pixels (white on the dark menu so it shows up). */
    public static void drawSaturn(GuiGraphics g, int x0, int y0, int px) {
        int[][] gr = saturnGrid();
        for (int y = 0; y < gr.length; y++) {
            for (int x = 0; x < gr[y].length; x++) {
                if (gr[y][x] == 0) continue;
                int col = gr[y][x] == 1 ? 0xFFFFFFFF : 0xFF1DB954;
                g.fill(x0 + x * px, y0 + y * px, x0 + (x + 1) * px, y0 + (y + 1) * px, col);
            }
        }
    }
}
