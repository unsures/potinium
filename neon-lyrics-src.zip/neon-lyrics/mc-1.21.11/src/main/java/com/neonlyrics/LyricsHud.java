package com.neonlyrics;

import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;

/**
 * Draws the lyrics in two places: flat on the screen, and "in the world" (a 3D position projected onto
 * the screen, so it floats at a fixed spot in front of you and gets smaller the further away you set it).
 */
public final class LyricsHud {
    private LyricsHud() {
    }

    private static float anchorYaw;
    private static boolean anchorInit;
    private static long lastNanos;

    public static void recenter() {
        anchorInit = false;
    }

    public static void render(GuiGraphics g, DeltaTracker tracker) {
        Config cfg = NeonLyricsClient.CONFIG;
        Minecraft mc = Minecraft.getInstance();
        if (cfg == null || mc.player == null) return;
        // The menus sit on a lavender glass panel. It is drawn here, underneath the menu, so the game's
        // own menu blur softens it into a blurry see-through background.
        if (mc.screen instanceof SongMenuScreen || mc.screen instanceof SettingsScreen) {
            drawPanel(g, mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight());
        }
        if (mc.options.hideGui) return;
        if (!cfg.showScreen && !cfg.showWorld) return;

        PlaybackState st = SpotifyClient.get().state();
        if (st.track() == null) return;

        java.util.List<LyricsService.Line> lines = NeonLyricsClient.LYRICS.lines();
        String text;
        float alpha;
        if (lines.isEmpty()) {
            text = NeonLyricsClient.LYRICS.status();
            alpha = 0.7f;
        } else {
            long pos = st.positionMs() + cfg.lyricOffsetMs;
            LyricMath.Frame f = LyricMath.frame(lines, pos, cfg, st.track().durationMs());
            text = f.text();
            alpha = f.alpha();
        }
        if (text == null || text.isBlank() || alpha < 0.02f) return;

        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0.016f : Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        float timeSec = now / 1e9f;
        int rgb = LyricMath.color(cfg, timeSec);

        Font font = mc.font;
        String shown = LyricMath.transform(text, cfg.fontIndex);
        MutableComponent comp = Component.literal(shown);
        if (LyricMath.bold(cfg.fontIndex)) comp = comp.withStyle(ChatFormatting.BOLD);
        if (LyricMath.italic(cfg.fontIndex)) comp = comp.withStyle(ChatFormatting.ITALIC);
        if (LyricMath.underline(cfg.fontIndex)) comp = comp.withStyle(ChatFormatting.UNDERLINE);

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        // ---- on the screen
        if (cfg.showScreen) {
            drawNeon(g, font, comp, sw / 2f, sh * (cfg.screenYPercent / 100f), cfg.screenScale, rgb, alpha);
        }

        // ---- in the world
        if (cfg.showWorld) {
            float pt = tracker.getGameTimeDeltaPartialTick(false);
            float yaw = mc.player.getViewYRot(pt);
            float pitch = mc.player.getViewXRot(pt);
            if (!anchorInit) {
                anchorYaw = yaw;
                anchorInit = true;
            } else if (cfg.followCamera) {
                float diff = Mth.wrapDegrees(yaw - anchorYaw);
                anchorYaw += diff * (1f - (float) Math.pow(0.02, dt));
            }
            double a = Math.toRadians(anchorYaw);
            double dx = -Math.sin(a) * cfg.distance;
            double dz = Math.cos(a) * cfg.distance;
            float[] p = LyricMath.project(dx, cfg.height, dz, yaw, pitch, mc.options.fov().get(), sw, sh);
            if (p != null) {
                // Text is about 0.025 blocks per pixel at close range and grows with distance so it stays readable.
                float blocksPerPixel = 0.025f * cfg.worldScale * (1f + cfg.distance / 8f);
                float scale = blocksPerPixel * p[2];
                scale = Mth.clamp(scale, 0.15f, 14f);
                drawNeon(g, font, comp, p[0], p[1], scale, rgb, alpha);
            }
        }
    }

    private static void drawNeon(GuiGraphics g, Font font, Component text, float cx, float cy,
                                 float scale, int rgb, float alpha) {
        int w = font.width(text);
        int x = -w / 2;
        int y = -font.lineHeight / 2;
        g.pose().pushMatrix();
        g.pose().translate(cx, cy);
        g.pose().scale(scale, scale);

        // glow: two rings of soft copies in the neon colour
        int halo2 = LyricMath.argb(alpha * 0.12f, rgb);
        int halo1 = LyricMath.argb(alpha * 0.28f, rgb);
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};
        if (alpha > 0.03f) {
            for (int[] d : dirs) g.drawString(font, text, x + d[0] * 2, y + d[1] * 2, halo2, false);
            for (int[] d : dirs) g.drawString(font, text, x + d[0], y + d[1], halo1, false);
        }
        // bright tube core
        int core = LyricMath.argb(alpha, LyricMath.mix(rgb, 0xFFFFFF, 0.6f));
        g.drawString(font, text, x, y, core, false);

        g.pose().popMatrix();
    }

    // ------------------------------------------------------------------ menu look

    private static final int LAVENDER = 0xB69CE6;

    public static void drawPanel(GuiGraphics g, int sw, int sh) {
        int x1 = sw / 2 - 160;
        int x2 = sw / 2 + 160;
        for (int i = 10; i >= 1; i--) {
            g.fill(x1 - i, 0, x2 + i, sh, LyricMath.argb(0.05f, LAVENDER)); // soft glowing edge
        }
        g.fill(x1, 0, x2, sh, LyricMath.argb(0.55f, LAVENDER));
        g.fill(x1, 0, x2, 1, LyricMath.argb(0.9f, 0xE6E6FA));
    }

    private static int[][] saturn;

    private static int[][] saturnGrid() {
        if (saturn != null) return saturn;
        int w = 19, h = 13;
        int[][] gr = new int[h][w];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if ((x - 9) * (x - 9) + (y - 6) * (y - 6) <= 15) gr[y][x] = 1;
            }
        }
        double phi = Math.toRadians(20), cp = Math.cos(phi), sp = Math.sin(phi);
        for (int i = 0; i < 720; i++) {
            double t = i * 2 * Math.PI / 720;
            double a = 8.7 * Math.cos(t), b = 2.6 * Math.sin(t);
            int xi = (int) Math.round(9 + a * cp - b * sp);
            int yi = (int) Math.round(6 - (a * sp + b * cp));
            if (xi < 0 || xi >= w || yi < 0 || yi >= h) continue;
            if (gr[yi][xi] == 1) {
                if (Math.sin(t) < 0) gr[yi][xi] = 2; // front of the ring passes over the planet
            } else {
                gr[yi][xi] = 1;
            }
        }
        saturn = gr;
        return gr;
    }

    /** A small black Saturn made of pixels. */
    public static void drawSaturn(GuiGraphics g, int x0, int y0, int px) {
        int[][] gr = saturnGrid();
        for (int y = 0; y < gr.length; y++) {
            for (int x = 0; x < gr[y].length; x++) {
                if (gr[y][x] == 0) continue;
                int col = gr[y][x] == 1 ? 0xFF000000 : 0xFFE6E6FA;
                g.fill(x0 + x * px, y0 + y * px, x0 + (x + 1) * px, y0 + (y + 1) * px, col);
            }
        }
    }
}
