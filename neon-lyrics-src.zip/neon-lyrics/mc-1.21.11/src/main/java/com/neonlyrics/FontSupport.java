package com.neonlyrics;

import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

/** The "Handwritten" font. Kept in its own file so the build can swap in a safe version if needed. */
final class FontSupport {
    private FontSupport() {
    }

    static MutableComponent script(MutableComponent c) {
        return c.withStyle(Style.EMPTY.withFont(
                new FontDescription.Resource(Identifier.fromNamespaceAndPath("neonlyrics", "script"))));
    }
}
