package com.neonlyrics;

import net.minecraft.client.gui.GuiGraphics;

/** Tiny drawing helpers: rounded rectangles and circles made from thin strips. */
final class Ui {
    private Ui() {
    }

    static void roundRect(GuiGraphics g, int x, int y, int w, int h, int r, int argb) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.ceil(r - Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, argb);
            g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, argb);
        }
        g.fill(x, y + r, x + w, y + h - r, argb);
    }

    static void circle(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }
}
