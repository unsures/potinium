package com.neonlyrics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Opens with B. Browse / search songs, build a queue, tap a song to play it. Drag the top bar to move it. */
public class SongMenuScreen extends Screen {
    private enum Tab {LIKED, PLAYLISTS, SEARCH, LRC, QUEUE}

    private record Row(String title, String sub, Runnable click, String actionLabel, Runnable action) {
        Row(String title, String sub, Runnable click) {
            this(title, sub, click, null, null);
        }
    }

    private static final int ROW_H = 22;
    private static final int MAX_ROWS = 8;
    private static final int GREEN = 0xFF1DB954;

    private Tab tab = Tab.LIKED;
    private final List<Row> items = new ArrayList<>();
    private int page;
    private int visibleRows = 4;
    private int rowsTop = 42;
    private String status = "";
    private boolean loaded;
    private final boolean offline;
    private final MenuDrag drag = new MenuDrag();

    private EditBox searchField;
    private EditBox clientIdField;
    private EditBox pasteField;
    private Button goButton, prevPage, nextPage;
    private final Button[] rowButtons = new Button[MAX_ROWS];
    private final Button[] actionButtons = new Button[MAX_ROWS];
    private final List<Button> tabButtons = new ArrayList<>();
    private boolean connectMode;

    public SongMenuScreen() {
        this(false);
    }

    /** offline = "lyrics only" mode: no Spotify, search lrclib.net directly. */
    public SongMenuScreen(boolean offline) {
        super(Component.literal("Potinium"));
        this.offline = offline;
        if (offline) tab = Tab.LRC;
    }

    /** True while a text box has the keyboard, so pressing B types a "b" instead of closing the menu. */
    public boolean isTyping() {
        return (searchField != null && searchField.isFocused())
                || (clientIdField != null && clientIdField.isFocused())
                || (pasteField != null && pasteField.isFocused());
    }

    // ------------------------------------------------------------------ layout

    @Override
    protected void init() {
        connectMode = !SpotifyClient.get().isLoggedIn() && !offline;
        if (connectMode) {
            initConnect();
        } else {
            initMain();
        }
        drag.trackAll(this.children());
        if (!connectMode) layoutList(); // row positions are kept as "base" spots, so set them after tracking
        drag.apply();
    }

    private void initConnect() {
        int cx = this.width / 2;
        int y0 = Math.max(70, this.height / 2 - 30);
        clientIdField = new EditBox(this.font, cx - 130, y0, 260, 20, Component.literal("Client ID"));
        clientIdField.setMaxLength(64);
        clientIdField.setValue(NeonLyricsClient.CONFIG.clientId == null ? "" : NeonLyricsClient.CONFIG.clientId);
        this.addRenderableWidget(clientIdField);

        this.addRenderableWidget(Button.builder(Component.literal("Link Spotify"), b -> connect())
                .bounds(cx - 130, y0 + 24, 84, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Lyrics only"),
                b -> this.minecraft.setScreen(new SongMenuScreen(true))).bounds(cx - 42, y0 + 24, 84, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(cx + 46, y0 + 24, 84, 20).build());

        pasteField = new EditBox(this.font, cx - 130, y0 + 66, 190, 20, Component.literal("Paste address"));
        pasteField.setMaxLength(1000);
        this.addRenderableWidget(pasteField);
        this.addRenderableWidget(Button.builder(Component.literal("Finish"), b -> {
            String v = pasteField.getValue().trim();
            if (!v.isEmpty()) SpotifyClient.get().finishLoginFromUrl(v);
        }).bounds(cx + 64, y0 + 66, 66, 20).build());
    }

    private void connect() {
        String id = clientIdField.getValue().trim();
        if (id.isEmpty()) {
            status = "Paste your Client ID first.";
            return;
        }
        NeonLyricsClient.CONFIG.clientId = id;
        NeonLyricsClient.CONFIG.save();
        try {
            String url = SpotifyClient.get().beginLogin(id);
            boolean copied = false;
            try {
                long w = GLFW.glfwGetCurrentContext();
                if (w != 0) {
                    GLFW.glfwSetClipboardString(w, url);
                    copied = true;
                }
            } catch (Throwable ignored) {
            }
            boolean opened = false;
            try {
                if (java.awt.Desktop.isDesktopSupported()
                        && java.awt.Desktop.getDesktop().isSupported(java.awt.Desktop.Action.BROWSE)) {
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
                    opened = true;
                }
            } catch (Throwable ignored) {
            }
            try {
                java.nio.file.Files.writeString(
                        net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("neonlyrics_login_link.txt"), url);
            } catch (Throwable ignored) {
            }
            status = opened ? "Browser opened. Approve it, then come back here."
                    : (copied ? "Link copied. Paste it in your browser, approve, then come back here."
                    : "Open config/neonlyrics_login_link.txt, copy the link into your browser.");
        } catch (Exception e) {
            status = "Could not start login: " + e.getMessage();
        }
    }

    private void initMain() {
        int x = this.width / 2 - 150;
        int w = 300;
        int tw = (w - 16) / 5;
        tabButtons.clear();
        String[] names = {"Liked", "Playlists", "Search", "Lyrics", "Queue"};
        Tab[] tabs = {Tab.LIKED, Tab.PLAYLISTS, Tab.SEARCH, Tab.LRC, Tab.QUEUE};
        for (int i = 0; i < 5; i++) {
            final Tab tb = tabs[i];
            Button tbtn = Button.builder(Component.literal(names[i]), b -> setTab(tb))
                    .bounds(x + i * (tw + 4), 20, tw, 20).build();
            this.addRenderableWidget(tbtn);
            tabButtons.add(tbtn);
            if (offline && tb != Tab.LRC && tb != Tab.QUEUE) tbtn.visible = false;
        }

        searchField = new EditBox(this.font, x, 44, w - 44, 20, Component.literal("Search"));
        searchField.setMaxLength(100);
        this.addRenderableWidget(searchField);
        goButton = Button.builder(Component.literal("Go"), b -> doSearch()).bounds(x + w - 40, 44, 40, 20).build();
        this.addRenderableWidget(goButton);

        for (int i = 0; i < MAX_ROWS; i++) {
            final int n = i;
            rowButtons[i] = Button.builder(Component.empty(), b -> clickRow(n)).bounds(x, 0, w, 20).build();
            this.addRenderableWidget(rowButtons[i]);
            actionButtons[i] = Button.builder(Component.empty(), b -> clickAction(n)).bounds(x + w - 58, 0, 58, 20).build();
            this.addRenderableWidget(actionButtons[i]);
        }
        prevPage = Button.builder(Component.literal("<"), b -> turnPage(-1)).bounds(x, 0, 30, 20).build();
        nextPage = Button.builder(Component.literal(">"), b -> turnPage(1)).bounds(x + w - 30, 0, 30, 20).build();
        this.addRenderableWidget(prevPage);
        this.addRenderableWidget(nextPage);

        int by = this.height - 22;
        int bw = 52;
        this.addRenderableWidget(Button.builder(Component.literal("<<"),
                b -> {
                    if (SpotifyClient.get().isManual()) SpotifyClient.get().manualSeek(-5000);
                    else run(SpotifyClient.get().previous());
                }).bounds(x, by, bw, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Play/Pause"),
                b -> {
                    if (SpotifyClient.get().isManual()) SpotifyClient.get().manualToggle();
                    else run(SpotifyClient.get().togglePause());
                }).bounds(x + bw + 4, by, 84, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(">>"),
                b -> {
                    if (SpotifyClient.get().isManual()) SpotifyClient.get().manualSeek(5000);
                    else run(SpotifyClient.get().next());
                }).bounds(x + bw + 92, by, bw, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Settings"),
                b -> this.minecraft.setScreen(new SettingsScreen(this))).bounds(x + 2 * bw + 96, by, 60, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(x + 2 * bw + 160, by, w - (2 * bw + 160), 20).build());

        layoutList();
        updateQueueTab();
        if (!loaded) {
            loaded = true;
            setTab(tab);
        } else {
            refreshRows();
        }
    }

    private void layoutList() {
        boolean search = tab == Tab.SEARCH || tab == Tab.LRC;
        searchField.visible = search;
        goButton.visible = search;
        rowsTop = search ? 68 : 44;
        int space = this.height - 76 - rowsTop - 22;
        visibleRows = Math.max(2, Math.min(MAX_ROWS, space / ROW_H));
        for (int i = 0; i < MAX_ROWS; i++) {
            drag.setBaseY(rowButtons[i], rowsTop + i * ROW_H);
            drag.setBaseY(actionButtons[i], rowsTop + i * ROW_H);
        }
        int py = rowsTop + visibleRows * ROW_H + 2;
        drag.setBaseY(prevPage, py);
        drag.setBaseY(nextPage, py);
    }

    private void refreshRows() {
        int pages = Math.max(1, (items.size() + visibleRows - 1) / visibleRows);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < MAX_ROWS; i++) {
            int idx = page * visibleRows + i;
            boolean show = i < visibleRows && idx < items.size();
            rowButtons[i].visible = show;
            rowButtons[i].active = show;
            actionButtons[i].visible = false;
            actionButtons[i].active = false;
            if (show) {
                Row r = items.get(idx);
                boolean hasAction = r.actionLabel() != null;
                int rw = hasAction ? 238 : 300;
                rowButtons[i].setWidth(rw);
                String label = r.sub().isEmpty() ? r.title() : r.title() + "  -  " + r.sub();
                rowButtons[i].setMessage(Component.literal(fit(label, rw - 14)));
                if (hasAction) {
                    actionButtons[i].visible = true;
                    actionButtons[i].active = true;
                    actionButtons[i].setMessage(Component.literal(r.actionLabel()));
                }
            }
        }
        prevPage.visible = nextPage.visible = items.size() > visibleRows;
    }

    private String fit(String s, int px) {
        if (this.font.width(s) <= px) return s;
        while (s.length() > 1 && this.font.width(s + "...") > px) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    private void clickRow(int i) {
        int idx = page * visibleRows + i;
        if (idx >= 0 && idx < items.size()) items.get(idx).click().run();
    }

    private void clickAction(int i) {
        int idx = page * visibleRows + i;
        if (idx >= 0 && idx < items.size() && items.get(idx).action() != null) items.get(idx).action().run();
    }

    private void turnPage(int d) {
        page += d;
        refreshRows();
    }

    private void updateQueueTab() {
        if (tabButtons.size() == 5) {
            int n = SongQueue.size();
            tabButtons.get(4).setMessage(Component.literal(n == 0 ? "Queue" : "Queue " + n));
        }
    }

    // ------------------------------------------------------------------ data

    private void setTab(Tab t) {
        tab = t;
        page = 0;
        items.clear();
        layoutList();
        switch (t) {
            case LIKED -> loadLiked();
            case PLAYLISTS -> loadPlaylists();
            case SEARCH -> status = "Type a song or artist, then press Go.";
            case LRC -> status = "Type a song + artist, press Go, pick it, then start the song and press Play/Pause here at the same time.";
            case QUEUE -> loadQueue();
        }
        refreshRows();
    }

    private void ui(Runnable r) {
        Minecraft.getInstance().execute(r);
    }

    private void queueAdd(Track t, String synced) {
        SongQueue.add(new SongQueue.Entry(t, synced));
        status = "Added to queue: " + t.name() + "  (" + SongQueue.size() + " in queue)";
        updateQueueTab();
    }

    private void loadQueue() {
        items.clear();
        page = 0;
        List<SongQueue.Entry> q = SongQueue.snapshot();
        if (q.isEmpty()) {
            status = "Your queue is empty. Use + Queue next to a song.";
        } else {
            status = q.size() + " in queue. Tap a song to play it now, or Remove it.";
            items.add(new Row("Clear whole queue", "", () -> {
                SongQueue.clear();
                updateQueueTab();
                loadQueue();
            }));
            for (int i = 0; i < q.size(); i++) {
                final int idx = i;
                SongQueue.Entry e = q.get(i);
                items.add(new Row((i + 1) + ". " + e.track().name(), e.track().artist(), () -> {
                    SongQueue.remove(idx);
                    SongQueue.playNow(e);
                    updateQueueTab();
                    loadQueue();
                }, "Remove", () -> {
                    SongQueue.remove(idx);
                    updateQueueTab();
                    loadQueue();
                }));
            }
        }
        updateQueueTab();
        refreshRows();
    }

    private void loadLiked() {
        status = "Loading liked songs...";
        SpotifyClient.get().likedSongs().whenComplete((list, err) -> ui(() -> {
            if (tab != Tab.LIKED) return;
            if (err != null) status = msg(err);
            else showTracks(list, null, false);
        }));
    }

    private void loadPlaylists() {
        status = "Loading playlists...";
        SpotifyClient.get().playlists().whenComplete((list, err) -> ui(() -> {
            if (tab != Tab.PLAYLISTS) return;
            if (err != null) {
                status = msg(err);
                return;
            }
            items.clear();
            page = 0;
            for (SpotifyClient.PlaylistInfo p : list) {
                items.add(new Row(p.name(), p.total() + " tracks", () -> openPlaylist(p)));
            }
            status = list.isEmpty() ? "No playlists found." : "";
            refreshRows();
        }));
    }

    private void openPlaylist(SpotifyClient.PlaylistInfo p) {
        status = "Loading " + p.name() + "...";
        SpotifyClient.get().playlistTracks(p.id()).whenComplete((list, err) -> ui(() -> {
            if (err != null) status = msg(err);
            else showTracks(list, p.uri(), true);
        }));
    }

    private void doSearch() {
        String q = searchField.getValue().trim();
        if (q.isEmpty()) return;
        status = "Searching...";
        if (tab == Tab.LRC) {
            NeonLyricsClient.LYRICS.searchAll(q).whenComplete((list, err) -> ui(() -> {
                if (err != null) {
                    status = msg(err);
                    return;
                }
                items.clear();
                page = 0;
                for (LyricsService.Result res : list) {
                    Track t = res.track();
                    items.add(new Row(t.name(), t.artist(), () -> {
                        SpotifyClient.get().startManual(t);
                        NeonLyricsClient.LYRICS.showManual(res);
                        status = "Ready: start the song and press Play/Pause here at the same time.";
                    }, "+ Queue", () -> queueAdd(t, res.synced())));
                }
                status = list.isEmpty() ? "No synced lyrics found for that." : "";
                refreshRows();
            }));
            return;
        }
        SpotifyClient.get().search(q).whenComplete((list, err) -> ui(() -> {
            if (err != null) status = msg(err);
            else showTracks(list, null, false);
        }));
    }

    private void showTracks(List<Track> tracks, String contextUri, boolean withBack) {
        items.clear();
        page = 0;
        if (withBack) items.add(new Row("< Back to playlists", "", this::loadPlaylists));
        for (int i = 0; i < tracks.size(); i++) {
            final int idx = i;
            Track t = tracks.get(i);
            items.add(new Row(t.name(), t.artist(), () -> {
                status = "Playing " + t.name() + "...";
                run(contextUri != null
                        ? SpotifyClient.get().playContext(contextUri, t.uri())
                        : SpotifyClient.get().playTracks(tracks, idx));
            }, "+ Queue", () -> queueAdd(t, null)));
        }
        status = tracks.isEmpty() ? "Nothing here." : "";
        refreshRows();
    }

    private void run(CompletableFuture<Void> f) {
        f.whenComplete((v, err) -> ui(() -> {
            if (err != null) status = msg(err);
            else if (status.startsWith("Playing")) status = "";
        }));
    }

    private static String msg(Throwable e) {
        Throwable c = e;
        while (c.getCause() != null && (c.getMessage() == null || c.getMessage().startsWith("java."))) c = c.getCause();
        return c.getMessage() == null ? c.toString() : c.getMessage();
    }

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        if (connectMode && SpotifyClient.get().isLoggedIn()) {
            this.minecraft.setScreen(new SongMenuScreen());
            return;
        }
        drag.update(mouseX, mouseY, this.width, this.height);
        super.render(g, mouseX, mouseY, delta);

        g.pose().pushMatrix();
        g.pose().translate((float) MenuDrag.offX, (float) MenuDrag.offY);
        if (connectMode) renderConnect(g);
        else renderMain(g);
        g.pose().popMatrix();
    }

    private void renderConnect(GuiGraphics g) {
        int cx = this.width / 2;
        LyricsHud.drawSaturn(g, cx - 150, 2, 1);
        g.drawString(this.font, "POTINIUM", cx - 126, 4, GREEN, true);
        String[] steps = {
                "Link your Spotify (one time)  -  or tap Lyrics only if Spotify blocks you",
                "1. Open developer.spotify.com/dashboard and create an app.",
                "2. Add this Redirect URI exactly:  " + SpotifyClient.REDIRECT_URI,
                "3. Tick \"Web API\", save, then copy the app's Client ID.",
                "4. Paste it below and press Link Spotify.",
        };
        for (int i = 0; i < steps.length; i++) {
            g.drawString(this.font, fit(steps[i], 310), cx - 155, 20 + i * 11, i == 0 ? 0xFFFFFFFF : 0xFFB3B3B3, true);
        }
        int y0 = Math.max(70, this.height / 2 - 30);
        g.drawString(this.font, "Client ID", cx - 130, y0 - 10, 0xFFB3B3B3, true);
        g.drawString(this.font, "If the browser page didn't load, paste its address here:", cx - 130, y0 + 54, 0xFFB3B3B3, true);
        String m = !SpotifyClient.get().loginMessage.isEmpty() ? SpotifyClient.get().loginMessage : status;
        if (!m.isEmpty()) g.drawString(this.font, fit(m, 310), cx - 155, y0 + 94, 0xFFFFCC55, true);
    }

    private void renderMain(GuiGraphics g) {
        int cx = this.width / 2;
        int left = cx - 150;
        LyricsHud.drawSaturn(g, left, 2, 1);
        g.drawString(this.font, "POTINIUM", left + 24, 4, GREEN, true);
        String hint = "drag this bar to move";
        g.drawString(this.font, hint, cx + 150 - this.font.width(hint), 4, 0xFF777777, false);

        int pages = Math.max(1, (items.size() + visibleRows - 1) / visibleRows);
        if (items.size() > visibleRows) {
            String pg = (page + 1) + " / " + pages;
            g.drawString(this.font, pg, cx - this.font.width(pg) / 2, rowsTop + visibleRows * ROW_H + 8, 0xFFB3B3B3, true);
        }

        // status line
        if (!status.isEmpty()) g.drawString(this.font, fit(status, 300), left, this.height - 72, 0xFFFFCC55, true);

        // now playing card
        int top = this.height - 58;
        g.fill(left, top, left + 30, top + 30, 0xFF1DB954);
        g.drawString(this.font, "♪", left + 11, top + 11, 0xFF000000, false);
        PlaybackState st = SpotifyClient.get().state();
        String title, artist;
        if (st.track() == null) {
            title = "Nothing playing";
            artist = SpotifyClient.get().isLoggedIn() ? "Start a song in Spotify" : "Pick a song in the Lyrics tab";
        } else {
            title = (st.playing() ? "" : "(paused) ") + st.track().name();
            artist = st.track().artist();
        }
        g.drawString(this.font, fit(title, 262), left + 36, top, 0xFFFFFFFF, true);
        g.drawString(this.font, fit(artist, 262), left + 36, top + 10, 0xFFB3B3B3, true);
        int barX = left + 36, barW = 264, barY = top + 23;
        g.fill(barX, barY, barX + barW, barY + 3, 0xFF535353);
        if (st.track() != null && st.track().durationMs() > 0) {
            float frac = Math.min(1f, st.positionMs() / (float) st.track().durationMs());
            g.fill(barX, barY, barX + Math.round(barW * frac), barY + 3, GREEN);
            String time = fmt(st.positionMs()) + " / " + fmt(st.track().durationMs());
            g.drawString(this.font, time, barX + barW - this.font.width(time), top + 11, 0xFF777777, false);
        }
        String ly = NeonLyricsClient.LYRICS.status();
        if (st.track() != null && !ly.isEmpty()) g.drawString(this.font, fit(ly, 200), left + 36, top + 28, 0xFFB69CE6, false);
    }
}
