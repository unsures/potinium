package com.neonlyrics;

import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;

/**
 * Draws the lyrics in two places: flat on the screen, and "in the world" (a 3D position projected onto
 * the screen, so it floats at a fixed spot in front of you and gets smaller the further away you set it).
 */
public final class LyricsHud {
    private LyricsHud() {
    }

    private static float anchorYaw;
    private static boolean anchorInit;
    private static long lastNanos;

    public static void recenter() {
        anchorInit = false;
    }

    public static void render(GuiGraphicsExtractor g, DeltaTracker tracker) {
        Config cfg = NeonLyricsClient.CONFIG;
        Minecraft mc = Minecraft.getInstance();
        if (cfg == null || mc.player == null || mc.options.hideGui) return;
        if (!cfg.showScreen && !cfg.showWorld) return;

        PlaybackState st = SpotifyClient.get().state();
        if (st.track() == null) return;

        java.util.List<LyricsService.Line> lines = NeonLyricsClient.LYRICS.lines();
        String text;
        float alpha;
        if (lines.isEmpty()) {
            text = NeonLyricsClient.LYRICS.status();
            alpha = 0.7f;
        } else {
            long pos = st.positionMs() + cfg.lyricOffsetMs;
            LyricMath.Frame f = LyricMath.frame(lines, pos, cfg, st.track().durationMs());
            text = f.text();
            alpha = f.alpha();
        }
        if (text == null || text.isBlank() || alpha < 0.02f) return;

        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0.016f : Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        float timeSec = now / 1e9f;
        int rgb = LyricMath.color(cfg, timeSec);

        Font font = mc.font;
        String shown = LyricMath.transform(text, cfg.fontIndex);
        MutableComponent comp = Component.literal(shown);
        if (LyricMath.bold(cfg.fontIndex)) comp = comp.withStyle(ChatFormatting.BOLD);
        if (LyricMath.italic(cfg.fontIndex)) comp = comp.withStyle(ChatFormatting.ITALIC);
        if (LyricMath.underline(cfg.fontIndex)) comp = comp.withStyle(ChatFormatting.UNDERLINE);

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        // ---- on the screen
        if (cfg.showScreen) {
            drawNeon(g, font, comp, sw / 2f, sh * (cfg.screenYPercent / 100f), cfg.screenScale, rgb, alpha);
        }

        // ---- in the world
        if (cfg.showWorld) {
            float pt = tracker.getGameTimeDeltaPartialTick(false);
            float yaw = mc.player.getViewYRot(pt);
            float pitch = mc.player.getViewXRot(pt);
            if (!anchorInit) {
                anchorYaw = yaw;
                anchorInit = true;
            } else if (cfg.followCamera) {
                float diff = Mth.wrapDegrees(yaw - anchorYaw);
                anchorYaw += diff * (1f - (float) Math.pow(0.02, dt));
            }
            double a = Math.toRadians(anchorYaw);
            double dx = -Math.sin(a) * cfg.distance;
            double dz = Math.cos(a) * cfg.distance;
            float[] p = LyricMath.project(dx, cfg.height, dz, yaw, pitch, mc.options.fov().get(), sw, sh);
            if (p != null) {
                // Text is about 0.025 blocks per pixel at close range and grows with distance so it stays readable.
                float blocksPerPixel = 0.025f * cfg.worldScale * (1f + cfg.distance / 8f);
                float scale = blocksPerPixel * p[2];
                scale = Mth.clamp(scale, 0.15f, 14f);
                drawNeon(g, font, comp, p[0], p[1], scale, rgb, alpha);
            }
        }
    }

    private static void drawNeon(GuiGraphicsExtractor g, Font font, Component text, float cx, float cy,
                                 float scale, int rgb, float alpha) {
        int w = font.width(text);
        int x = -w / 2;
        int y = -font.lineHeight / 2;
        g.pose().pushMatrix();
        g.pose().translate(cx, cy);
        g.pose().scale(scale, scale);

        // glow: two rings of soft copies in the neon colour
        int halo2 = LyricMath.argb(alpha * 0.12f, rgb);
        int halo1 = LyricMath.argb(alpha * 0.28f, rgb);
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};
        if (alpha > 0.03f) {
            for (int[] d : dirs) g.text(font, text, x + d[0] * 2, y + d[1] * 2, halo2, false);
            for (int[] d : dirs) g.text(font, text, x + d[0], y + d[1], halo1, false);
        }
        // bright tube core
        int core = LyricMath.argb(alpha, LyricMath.mix(rgb, 0xFFFFFF, 0.6f));
        g.text(font, text, x, y, core, false);

        g.pose().popMatrix();
    }
}
