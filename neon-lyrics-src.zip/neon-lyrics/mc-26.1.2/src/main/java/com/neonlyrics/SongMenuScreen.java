package com.neonlyrics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Opens with B. Browse liked songs / playlists / search, tap a song to play it on Spotify. */
public class SongMenuScreen extends Screen {
    private enum Tab {LIKED, PLAYLISTS, SEARCH}

    private record Row(String title, String sub, Runnable click) {
    }

    private static final int ROW_H = 22;
    private static final int MAX_ROWS = 8;

    private Tab tab = Tab.LIKED;
    private final List<Row> items = new ArrayList<>();
    private int page;
    private int visibleRows = 4;
    private int rowsTop = 46;
    private String status = "";
    private boolean loaded;

    private EditBox searchField;
    private EditBox clientIdField;
    private EditBox pasteField;
    private Button goButton, prevPage, nextPage;
    private final Button[] rowButtons = new Button[MAX_ROWS];
    private boolean connectMode;

    public SongMenuScreen() {
        super(Component.literal("Neon Lyrics"));
    }

    /** True while a text box has the keyboard, so pressing B types a "b" instead of closing the menu. */
    public boolean isTyping() {
        return (searchField != null && searchField.isFocused())
                || (clientIdField != null && clientIdField.isFocused())
                || (pasteField != null && pasteField.isFocused());
    }

    // ------------------------------------------------------------------ layout

    @Override
    protected void init() {
        connectMode = !SpotifyClient.get().isLoggedIn();
        if (connectMode) {
            initConnect();
        } else {
            initMain();
        }
    }

    private void initConnect() {
        int cx = this.width / 2;
        int y0 = Math.max(70, this.height / 2 - 30);
        clientIdField = new EditBox(this.font, cx - 130, y0, 260, 20, Component.literal("Client ID"));
        clientIdField.setMaxLength(64);
        clientIdField.setValue(NeonLyricsClient.CONFIG.clientId == null ? "" : NeonLyricsClient.CONFIG.clientId);
        this.addRenderableWidget(clientIdField);

        this.addRenderableWidget(Button.builder(Component.literal("Link Spotify"), b -> connect())
                .bounds(cx - 130, y0 + 24, 126, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(cx + 4, y0 + 24, 126, 20).build());

        pasteField = new EditBox(this.font, cx - 130, y0 + 66, 190, 20, Component.literal("Paste address"));
        pasteField.setMaxLength(1000);
        this.addRenderableWidget(pasteField);
        this.addRenderableWidget(Button.builder(Component.literal("Finish"), b -> {
            String v = pasteField.getValue().trim();
            if (!v.isEmpty()) SpotifyClient.get().finishLoginFromUrl(v);
        }).bounds(cx + 64, y0 + 66, 66, 20).build());
    }

    private void connect() {
        String id = clientIdField.getValue().trim();
        if (id.isEmpty()) {
            status = "Paste your Client ID first.";
            return;
        }
        NeonLyricsClient.CONFIG.clientId = id;
        NeonLyricsClient.CONFIG.save();
        try {
            String url = SpotifyClient.get().beginLogin(id);
            boolean copied = false;
            try {
                long w = GLFW.glfwGetCurrentContext();
                if (w != 0) {
                    GLFW.glfwSetClipboardString(w, url);
                    copied = true;
                }
            } catch (Throwable ignored) {
            }
            boolean opened = false;
            try {
                if (java.awt.Desktop.isDesktopSupported()
                        && java.awt.Desktop.getDesktop().isSupported(java.awt.Desktop.Action.BROWSE)) {
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
                    opened = true;
                }
            } catch (Throwable ignored) {
            }
            try {
                java.nio.file.Files.writeString(
                        net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("neonlyrics_login_link.txt"), url);
            } catch (Throwable ignored) {
            }
            status = opened ? "Browser opened. Approve it, then come back here."
                    : (copied ? "Link copied. Paste it in your browser, approve, then come back here."
                    : "Open config/neonlyrics_login_link.txt, copy the link into your browser.");
        } catch (Exception e) {
            status = "Could not start login: " + e.getMessage();
        }
    }

    private void initMain() {
        int x = this.width / 2 - 150;
        int w = 300;
        int tw = (w - 8) / 3;
        this.addRenderableWidget(Button.builder(Component.literal("Liked"), b -> setTab(Tab.LIKED))
                .bounds(x, 18, tw, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Playlists"), b -> setTab(Tab.PLAYLISTS))
                .bounds(x + tw + 4, 18, tw, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Search"), b -> setTab(Tab.SEARCH))
                .bounds(x + (tw + 4) * 2, 18, tw, 20).build());

        searchField = new EditBox(this.font, x, 42, w - 44, 20, Component.literal("Search"));
        searchField.setMaxLength(100);
        this.addRenderableWidget(searchField);
        goButton = Button.builder(Component.literal("Go"), b -> doSearch()).bounds(x + w - 40, 42, 40, 20).build();
        this.addRenderableWidget(goButton);

        for (int i = 0; i < MAX_ROWS; i++) {
            final int n = i;
            rowButtons[i] = Button.builder(Component.empty(), b -> clickRow(n)).bounds(x, 0, w, 20).build();
            this.addRenderableWidget(rowButtons[i]);
        }
        prevPage = Button.builder(Component.literal("<"), b -> turnPage(-1)).bounds(x, 0, 30, 20).build();
        nextPage = Button.builder(Component.literal(">"), b -> turnPage(1)).bounds(x + w - 30, 0, 30, 20).build();
        this.addRenderableWidget(prevPage);
        this.addRenderableWidget(nextPage);

        int by = this.height - 24;
        int bw = 52;
        this.addRenderableWidget(Button.builder(Component.literal("<<"),
                b -> run(SpotifyClient.get().previous())).bounds(x, by, bw, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Play/Pause"),
                b -> run(SpotifyClient.get().togglePause())).bounds(x + bw + 4, by, 84, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(">>"),
                b -> run(SpotifyClient.get().next())).bounds(x + bw + 92, by, bw, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Settings"),
                b -> this.minecraft.setScreen(new SettingsScreen(this))).bounds(x + 2 * bw + 96, by, 60, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(x + 2 * bw + 160, by, w - (2 * bw + 160), 20).build());

        layoutList();
        if (!loaded) {
            loaded = true;
            setTab(tab);
        } else {
            refreshRows();
        }
    }

    private void layoutList() {
        boolean search = tab == Tab.SEARCH;
        searchField.visible = search;
        goButton.visible = search;
        rowsTop = search ? 66 : 42;
        int space = this.height - 70 - rowsTop - 24;
        visibleRows = Math.max(2, Math.min(MAX_ROWS, space / ROW_H));
        for (int i = 0; i < MAX_ROWS; i++) rowButtons[i].setY(rowsTop + i * ROW_H);
        int py = rowsTop + visibleRows * ROW_H + 2;
        prevPage.setY(py);
        nextPage.setY(py);
    }

    private void refreshRows() {
        int pages = Math.max(1, (items.size() + visibleRows - 1) / visibleRows);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < MAX_ROWS; i++) {
            int idx = page * visibleRows + i;
            boolean show = i < visibleRows && idx < items.size();
            rowButtons[i].visible = show;
            rowButtons[i].active = show;
            if (show) {
                Row r = items.get(idx);
                String label = r.sub().isEmpty() ? r.title() : r.title() + "  -  " + r.sub();
                rowButtons[i].setMessage(Component.literal(fit(label, 286)));
            }
        }
        prevPage.visible = nextPage.visible = items.size() > visibleRows;
    }

    private String fit(String s, int px) {
        if (this.font.width(s) <= px) return s;
        while (s.length() > 1 && this.font.width(s + "...") > px) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    private void clickRow(int i) {
        int idx = page * visibleRows + i;
        if (idx >= 0 && idx < items.size()) items.get(idx).click().run();
    }

    private void turnPage(int d) {
        page += d;
        refreshRows();
    }

    // ------------------------------------------------------------------ data

    private void setTab(Tab t) {
        tab = t;
        page = 0;
        items.clear();
        layoutList();
        switch (t) {
            case LIKED -> loadLiked();
            case PLAYLISTS -> loadPlaylists();
            case SEARCH -> status = "Type a song or artist, then press Go.";
        }
        refreshRows();
    }

    private void ui(Runnable r) {
        Minecraft.getInstance().execute(r);
    }

    private void loadLiked() {
        status = "Loading liked songs...";
        SpotifyClient.get().likedSongs().whenComplete((list, err) -> ui(() -> {
            if (tab != Tab.LIKED) return;
            if (err != null) status = msg(err);
            else showTracks(list, null, false);
        }));
    }

    private void loadPlaylists() {
        status = "Loading playlists...";
        SpotifyClient.get().playlists().whenComplete((list, err) -> ui(() -> {
            if (tab != Tab.PLAYLISTS) return;
            if (err != null) {
                status = msg(err);
                return;
            }
            items.clear();
            page = 0;
            for (SpotifyClient.PlaylistInfo p : list) {
                items.add(new Row(p.name(), p.total() + " tracks", () -> openPlaylist(p)));
            }
            status = list.isEmpty() ? "No playlists found." : "";
            refreshRows();
        }));
    }

    private void openPlaylist(SpotifyClient.PlaylistInfo p) {
        status = "Loading " + p.name() + "...";
        SpotifyClient.get().playlistTracks(p.id()).whenComplete((list, err) -> ui(() -> {
            if (err != null) status = msg(err);
            else showTracks(list, p.uri(), true);
        }));
    }

    private void doSearch() {
        String q = searchField.getValue().trim();
        if (q.isEmpty()) return;
        status = "Searching...";
        SpotifyClient.get().search(q).whenComplete((list, err) -> ui(() -> {
            if (err != null) status = msg(err);
            else showTracks(list, null, false);
        }));
    }

    private void showTracks(List<Track> tracks, String contextUri, boolean withBack) {
        items.clear();
        page = 0;
        if (withBack) items.add(new Row("< Back to playlists", "", this::loadPlaylists));
        for (int i = 0; i < tracks.size(); i++) {
            final int idx = i;
            Track t = tracks.get(i);
            items.add(new Row(t.name(), t.artist(), () -> {
                status = "Playing " + t.name() + "...";
                run(contextUri != null
                        ? SpotifyClient.get().playContext(contextUri, t.uri())
                        : SpotifyClient.get().playTracks(tracks, idx));
            }));
        }
        status = tracks.isEmpty() ? "Nothing here." : "";
        refreshRows();
    }

    private void run(CompletableFuture<Void> f) {
        f.whenComplete((v, err) -> ui(() -> {
            if (err != null) status = msg(err);
            else if (status.startsWith("Playing")) status = "";
        }));
    }

    private static String msg(Throwable e) {
        Throwable c = e;
        while (c.getCause() != null && (c.getMessage() == null || c.getMessage().startsWith("java."))) c = c.getCause();
        return c.getMessage() == null ? c.toString() : c.getMessage();
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (connectMode && SpotifyClient.get().isLoggedIn()) {
            this.minecraft.setScreen(new SongMenuScreen());
            return;
        }
        super.extractRenderState(g, mouseX, mouseY, delta);
        int cx = this.width / 2;

        if (connectMode) {
            String[] steps = {
                    "Link your Spotify (one time)",
                    "1. On your phone/PC open developer.spotify.com/dashboard and create an app.",
                    "2. Add this Redirect URI exactly:  " + SpotifyClient.REDIRECT_URI,
                    "3. Tick \"Web API\", save, then copy the app's Client ID.",
                    "4. Paste it below and press Link Spotify. Playback control needs Spotify Premium.",
            };
            for (int i = 0; i < steps.length; i++) {
                g.text(this.font, steps[i], cx - this.font.width(steps[i]) / 2, 6 + i * 11,
                        i == 0 ? 0xFF00F6FF : 0xFFDDDDDD, true);
            }
            int y0 = Math.max(70, this.height / 2 - 30);
            g.text(this.font, "Client ID", cx - 130, y0 - 10, 0xFFAAAAAA, true);
            g.text(this.font, "If the browser page didn't load, paste its address here:", cx - 130, y0 + 54, 0xFFAAAAAA, true);
            String m = !SpotifyClient.get().loginMessage.isEmpty() ? SpotifyClient.get().loginMessage : status;
            if (!m.isEmpty()) g.text(this.font, fit(m, this.width - 20), 10, y0 + 94, 0xFFFFCC55, true);
            return;
        }

        g.text(this.font, "NEON LYRICS", this.width / 2 - 150, 6, 0xFF00F6FF, true);
        int pages = Math.max(1, (items.size() + visibleRows - 1) / visibleRows);
        if (items.size() > visibleRows) {
            String pg = (page + 1) + " / " + pages;
            g.text(this.font, pg, cx - this.font.width(pg) / 2, rowsTop + visibleRows * ROW_H + 8, 0xFFAAAAAA, true);
        }
        int bottom = this.height - 62;
        int left = cx - 150;
        if (!status.isEmpty()) g.text(this.font, fit(status, 300), left, bottom, 0xFFFFCC55, true);
        PlaybackState st = SpotifyClient.get().state();
        String np = st.track() == null
                ? "Nothing playing - start Spotify on any device"
                : (st.playing() ? "Playing: " : "Paused: ") + st.track().name() + " - " + st.track().artist();
        g.text(this.font, fit(np, 300), left, bottom + 12, 0xFF39FF14, true);
        String ly = NeonLyricsClient.LYRICS.status();
        if (st.track() != null && !ly.isEmpty()) g.text(this.font, fit(ly, 300), left, bottom + 24, 0xFFB04BFF, true);
    }
}
