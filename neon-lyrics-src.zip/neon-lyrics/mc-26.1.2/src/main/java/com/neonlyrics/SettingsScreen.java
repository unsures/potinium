package com.neonlyrics;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Tap-friendly settings: every value has a [-] and [+] button. Drag the top bar to move the menu. */
public class SettingsScreen extends Screen {
    private static final String[] TABS = {"World", "Place", "Screen", "Style", "Color", "Motion", "Misc"};

    private final Screen parent;
    private int tab;
    private final List<List<AbstractWidget>> tabWidgets = new ArrayList<>();
    private final List<Runnable> updaters = new ArrayList<>();
    private final MenuDrag drag = new MenuDrag();

    public SettingsScreen(Screen parent) {
        super(Component.literal("Potinium Settings"));
        this.parent = parent;
    }

    private Config c() {
        return NeonLyricsClient.CONFIG;
    }

    private static int cyc(int v, int d, int n) {
        return (v + d + n) % n;
    }

    @Override
    protected void init() {
        tabWidgets.clear();
        updaters.clear();
        int cx = this.width / 2;

        int tw = 41;
        int tx = cx - (TABS.length * tw + (TABS.length - 1) * 3) / 2;
        for (int i = 0; i < TABS.length; i++) {
            final int n = i;
            this.addRenderableWidget(Button.builder(Component.literal(TABS[i]), b -> showTab(n))
                    .bounds(tx + i * (tw + 3), 20, tw, 20).build());
            tabWidgets.add(new ArrayList<>());
        }

        Config c = c();

        // ---- World
        toggle(0, 0, "World lyrics", () -> c.showWorld, v -> c.showWorld = v);
        stepper(0, 1, "Distance", () -> Math.round(c.distance) + " blocks",
                () -> c.distance = Math.max(3, c.distance - 5), () -> c.distance = Math.min(200, c.distance + 5));
        stepper(0, 2, "Height", () -> Math.round(c.height) + " blocks",
                () -> c.height = Math.max(-10, c.height - 5), () -> c.height = Math.min(150, c.height + 5));
        stepper(0, 3, "Size", () -> String.format("%.2fx", c.worldScale),
                () -> c.worldScale = Math.max(0.25f, c.worldScale - 0.25f), () -> c.worldScale = Math.min(10f, c.worldScale + 0.25f));
        addTo(0, Button.builder(Component.literal("Preset: Near"), b -> {
            c.distance = 8;
            c.height = 1;
            c.worldScale = 1f;
            refresh();
        }).bounds(cx - 120, rowY(4), 118, 20).build());
        addTo(0, Button.builder(Component.literal("Preset: Far in the sky"), b -> {
            c.distance = 90;
            c.height = 70;
            c.worldScale = 2.5f;
            refresh();
        }).bounds(cx + 2, rowY(4), 118, 20).build());

        // ---- Place
        stepper(1, 0, "Placement", () -> LyricMath.PLACEMENT_NAMES[c.placement],
                () -> c.placement = cyc(c.placement, -1, LyricMath.PLACEMENT_NAMES.length),
                () -> c.placement = cyc(c.placement, 1, LyricMath.PLACEMENT_NAMES.length));
        stepper(1, 1, "Scatter spread", () -> c.spread + " deg",
                () -> c.spread = Math.max(10, c.spread - 5), () -> c.spread = Math.min(90, c.spread + 5));
        stepper(1, 2, "Scatter distance", () -> String.format("%.0f blocks", c.scatterDistance),
                () -> c.scatterDistance = Math.max(2, c.scatterDistance - 1), () -> c.scatterDistance = Math.min(40, c.scatterDistance + 1));
        stepper(1, 3, "Scatter size", () -> String.format("%.1fx", c.scatterScale),
                () -> c.scatterScale = Math.max(0.5f, c.scatterScale - 0.25f), () -> c.scatterScale = Math.min(10f, c.scatterScale + 0.25f));
        toggle(1, 4, "Rotate lyrics", () -> c.rotate, v -> c.rotate = v);
        toggle(1, 5, "Follow camera (in front)", () -> c.followCamera, v -> c.followCamera = v);

        // ---- Screen
        toggle(2, 0, "Screen lyrics", () -> c.showScreen, v -> c.showScreen = v);
        stepper(2, 3, "Screen style", () -> LyricMath.SCREEN_STYLE_NAMES[c.screenStyle],
                () -> c.screenStyle = cyc(c.screenStyle, -1, LyricMath.SCREEN_STYLE_NAMES.length),
                () -> c.screenStyle = cyc(c.screenStyle, 1, LyricMath.SCREEN_STYLE_NAMES.length));
        stepper(2, 1, "Size", () -> String.format("%.2fx", c.screenScale),
                () -> c.screenScale = Math.max(0.5f, c.screenScale - 0.25f), () -> c.screenScale = Math.min(6f, c.screenScale + 0.25f));
        stepper(2, 2, "Position", () -> c.screenYPercent + "% from top",
                () -> c.screenYPercent = Math.max(3, c.screenYPercent - 3), () -> c.screenYPercent = Math.min(95, c.screenYPercent + 3));

        // ---- Style
        stepper(3, 0, "Font", () -> LyricMath.FONT_NAMES[c.fontIndex],
                () -> c.fontIndex = cyc(c.fontIndex, -1, LyricMath.FONT_NAMES.length),
                () -> c.fontIndex = cyc(c.fontIndex, 1, LyricMath.FONT_NAMES.length));
        stepper(3, 1, "Fade in", () -> c.fadeInMs + " ms",
                () -> c.fadeInMs = Math.max(0, c.fadeInMs - 50), () -> c.fadeInMs = Math.min(2000, c.fadeInMs + 50));
        stepper(3, 2, "Fade out", () -> c.fadeOutMs + " ms",
                () -> c.fadeOutMs = Math.max(0, c.fadeOutMs - 50), () -> c.fadeOutMs = Math.min(2000, c.fadeOutMs + 50));

        // ---- Color
        stepper(4, 0, "Color", () -> LyricMath.COLOR_NAMES[c.colorIndex],
                () -> c.colorIndex = cyc(c.colorIndex, -1, LyricMath.COLOR_NAMES.length),
                () -> c.colorIndex = cyc(c.colorIndex, 1, LyricMath.COLOR_NAMES.length));
        stepper(4, 1, "Custom red", () -> String.valueOf(c.customR), () -> {
            c.customR = LyricMath.clamp255(c.customR - 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        }, () -> {
            c.customR = LyricMath.clamp255(c.customR + 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        });
        stepper(4, 2, "Custom green", () -> String.valueOf(c.customG), () -> {
            c.customG = LyricMath.clamp255(c.customG - 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        }, () -> {
            c.customG = LyricMath.clamp255(c.customG + 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        });
        stepper(4, 3, "Custom blue", () -> String.valueOf(c.customB), () -> {
            c.customB = LyricMath.clamp255(c.customB - 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        }, () -> {
            c.customB = LyricMath.clamp255(c.customB + 15);
            c.colorIndex = LyricMath.COLOR_NAMES.length - 1;
        });

        // ---- Motion (animation, intensity, delay, speed)
        stepper(5, 0, "Animation", () -> LyricMath.ANIM_NAMES[c.animation],
                () -> c.animation = cyc(c.animation, -1, LyricMath.ANIM_NAMES.length),
                () -> c.animation = cyc(c.animation, 1, LyricMath.ANIM_NAMES.length));
        stepper(5, 1, "Intensity", () -> LyricMath.INTENSITY_NAMES[c.intensity],
                () -> c.intensity = cyc(c.intensity, -1, LyricMath.INTENSITY_NAMES.length),
                () -> c.intensity = cyc(c.intensity, 1, LyricMath.INTENSITY_NAMES.length));
        stepper(5, 2, "Lyric delay", () -> (c.lyricOffsetMs > 0 ? "+" : "") + c.lyricOffsetMs + " ms",
                () -> c.lyricOffsetMs = Math.max(-8000, c.lyricOffsetMs - 50),
                () -> c.lyricOffsetMs = Math.min(8000, c.lyricOffsetMs + 50));
        stepper(5, 3, "Lyric speed", () -> String.format("%.2fx", c.lyricSpeed),
                () -> c.lyricSpeed = Math.max(0.5f, Math.round((c.lyricSpeed - 0.01f) * 100f) / 100f),
                () -> c.lyricSpeed = Math.min(2f, Math.round((c.lyricSpeed + 0.01f) * 100f) / 100f));
        int pw = 76;
        addTo(5, Button.builder(Component.literal("Slowed 0.85"), b -> {
            c.lyricSpeed = 0.85f;
            refresh();
        }).bounds(cx - 120, rowY(4), pw, 20).build());
        addTo(5, Button.builder(Component.literal("Normal 1.00"), b -> {
            c.lyricSpeed = 1f;
            c.lyricOffsetMs = 0;
            refresh();
        }).bounds(cx - 38, rowY(4), pw, 20).build());
        addTo(5, Button.builder(Component.literal("Sped up 1.15"), b -> {
            c.lyricSpeed = 1.15f;
            refresh();
        }).bounds(cx + 44, rowY(4), pw, 20).build());

        // ---- Misc
        stepper(6, 4, "Music volume", () -> c.musicVolume + "%",
                () -> c.musicVolume = Math.max(0, c.musicVolume - 10), () -> c.musicVolume = Math.min(100, c.musicVolume + 10));
        addTo(6, Button.builder(Component.literal("Link Spotify (optional)"),
                b -> this.minecraft.setScreen(new SongMenuScreen(true))).bounds(cx - 120, rowY(5), 240, 20).build());
        toggle(6, 0, "Open menu on join", () -> c.autoOpenOnJoin, v -> c.autoOpenOnJoin = v);
        addTo(6, Button.builder(Component.literal("Re-center lyrics (G)"), b -> LyricsHud.recenter())
                .bounds(cx - 120, rowY(1), 240, 20).build());
        addTo(6, Button.builder(Component.literal("Reset menu position"), b -> {
            MenuDrag.offX = 0;
            MenuDrag.offY = 0;
        }).bounds(cx - 120, rowY(2), 240, 20).build());
        addTo(6, Button.builder(Component.literal("Unlink Spotify"), b -> {
            SpotifyClient.get().logout();
            this.minecraft.setScreen(new SongMenuScreen());
        }).bounds(cx - 120, rowY(3), 240, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx - 60, this.height - 24, 120, 20).build());

        showTab(tab);
        refresh();
        drag.trackAll(this.children());
        drag.apply();
    }

    private int rowY(int row) {
        return 46 + row * 24;
    }

    private void addTo(int t, AbstractWidget w) {
        this.addRenderableWidget(w);
        tabWidgets.get(t).add(w);
    }

    private void toggle(int t, int row, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        Button b = Button.builder(Component.empty(), btn -> {
            set.accept(!get.get());
            refresh();
        }).bounds(this.width / 2 - 120, rowY(row), 240, 20).build();
        addTo(t, b);
        updaters.add(() -> b.setMessage(Component.literal(label + ": " + (get.get() ? "ON" : "OFF"))));
    }

    private void stepper(int t, int row, String label, Supplier<String> value, Runnable dec, Runnable inc) {
        int x = this.width / 2 - 120;
        int y = rowY(row);
        Button mid = Button.builder(Component.empty(), b -> {
        }).bounds(x + 28, y, 184, 20).build();
        addTo(t, Button.builder(Component.literal("-"), b -> {
            dec.run();
            refresh();
        }).bounds(x, y, 24, 20).build());
        addTo(t, mid);
        addTo(t, Button.builder(Component.literal("+"), b -> {
            inc.run();
            refresh();
        }).bounds(x + 216, y, 24, 20).build());
        updaters.add(() -> mid.setMessage(Component.literal(label + ": " + value.get())));
    }

    private void refresh() {
        for (Runnable r : updaters) r.run();
        c().save();
    }

    private void showTab(int t) {
        tab = t;
        for (int i = 0; i < tabWidgets.size(); i++) {
            for (AbstractWidget w : tabWidgets.get(i)) w.visible = i == t;
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        drag.update(mouseX, mouseY, this.width, this.height);
        MenuDrag.cards = true;
        MenuDrag.cardList1 = 42;
        MenuDrag.cardList2 = this.height - 46;
        MenuDrag.cardNow1 = -1;
        super.extractRenderState(g, mouseX, mouseY, delta);
        g.pose().pushMatrix();
        g.pose().translate((float) MenuDrag.offX, (float) MenuDrag.offY);
        int cx = this.width / 2;
        LyricsHud.drawSaturn(g, cx - 150, 2, 1);
        g.text(this.font, "POTINIUM  SETTINGS", cx - 126, 4, 0xFFB69CE6, true);
        String hint = switch (tab) {
            case 0 -> "Far + high = lyrics up in the sky. Near + low = close to you.";
            case 1 -> "Scatter: word groups pop up near you and stay put in the world.";
            case 2 -> "Rounded karaoke bar at the top, or floating neon text.";
            case 3 -> "Fade in/out controls how lines appear and disappear.";
            case 4 -> "Pick a color, or use the Custom red/green/blue buttons.";
            case 5 -> "Delay shifts lyrics. Speed fits slowed or sped-up songs.";
            default -> "Press B (or Close) to leave the song menu.";
        };
        g.text(this.font, hint, cx - this.font.width(hint) / 2, this.height - 40, 0xFFB3B3B3, true);
        g.pose().popMatrix();
    }

    @Override
    public void onClose() {
        c().save();
        this.minecraft.setScreen(parent);
    }
}
