package com.neonlyrics;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NeonLyricsClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("neonlyrics");
    public static Config CONFIG = new Config();
    public static final LyricsService LYRICS = new LyricsService();

    private static KeyMapping menuKey;
    private static KeyMapping recenterKey;
    private static boolean pendingOpen;
    private static boolean bWasDown;

    @Override
    public void onInitializeClient() {
        CONFIG = Config.load();

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("neonlyrics", "main"));
        menuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.neonlyrics.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, category));
        recenterKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.neonlyrics.recenter", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, category));

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("neonlyrics", "lyrics"),
                (graphics, tickCounter) -> LyricsHud.render(graphics, tickCounter));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> pendingOpen = CONFIG.autoOpenOnJoin);

        ClientTickEvents.END_CLIENT_TICK.register(NeonLyricsClient::tick);

        SpotifyClient.get().init();
        LOGGER.info("Neon Lyrics loaded. Press B in a world to open the song menu.");
    }

    private static void tick(Minecraft mc) {
        // B pressed again while the menu is open -> close it. (Vanilla ignores game keys inside screens,
        // so this checks the key directly.) Skipped while typing in a text box.
        boolean down = false;
        try {
            long window = GLFW.glfwGetCurrentContext();
            down = window != 0 && GLFW.glfwGetKey(window, GLFW.GLFW_KEY_B) == GLFW.GLFW_PRESS;
        } catch (Throwable ignored) {
        }
        if (down && !bWasDown && mc.screen instanceof SongMenuScreen menu && !menu.isTyping()) {
            menu.onClose();
        }
        bWasDown = down;
        SongQueue.tick();

        while (menuKey.consumeClick()) {
            if (mc.screen == null && mc.player != null) mc.setScreen(new SongMenuScreen());
        }
        while (recenterKey.consumeClick()) {
            LyricsHud.recenter();
        }
        if (pendingOpen && mc.player != null && mc.screen == null) {
            pendingOpen = false;
            mc.setScreen(new SongMenuScreen());
        }
    }
}
