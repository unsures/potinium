#!/bin/bash
# Usage: build.sh <minecraft version>   (run from the folder that contains "neon-lyrics")
# Tries each "gradle loom" pair listed in ci/<mc>.txt until one builds. Reports compile errors as annotations.
set -o pipefail
MC="$1"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/mc-$MC" || exit 1
n=0
ALLERR=""
while read -r GRADLE LOOM; do
  [ -z "$GRADLE" ] && continue
  n=$((n+1))
  echo "=== Attempt $n: Gradle $GRADLE, Loom $LOOM ==="
  DIST="$HOME/gradle-$GRADLE"
  if [ ! -d "$DIST" ]; then
    curl -sSL -o /tmp/g.zip "https://services.gradle.org/distributions/gradle-$GRADLE-bin.zip" && unzip -q -o /tmp/g.zip -d "$HOME"
  fi
  rm -rf build
  "$DIST/bin/gradle" build --no-daemon --stacktrace -Ploom_version="$LOOM" 2>&1 | tee "/tmp/build-$n.log"
  if [ "${PIPESTATUS[0]}" -eq 0 ]; then
    echo "Build OK with Gradle $GRADLE / Loom $LOOM"
    exit 0
  fi
  ERR=$(grep -E "error:|What went wrong|Could not (resolve|find|get|apply)|Unsupported|not supported|cannot find symbol|does not exist" -A2 "/tmp/build-$n.log" \
        | grep -v "^--$" | head -14 | tr '\n' '|' | sed 's/%/%25/g' | cut -c1-1400)
  echo "::error title=Minecraft $MC attempt $n (Gradle $GRADLE, Loom $LOOM) failed::$ERR"
done < "$ROOT/ci/$MC.txt"
echo "All attempts failed for $MC"
exit 1
