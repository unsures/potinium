#!/bin/bash
# Usage: build.sh <minecraft version>   (run from the folder that contains "neon-lyrics")
# Tries each "gradle loom variant" line in ci/<mc>.txt until one builds. Reports compile errors as annotations.
set -o pipefail
MC="$1"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/mc-$MC" || exit 1

# --- the handwritten font (downloaded here because the font file is not part of the zip)
FONTDIR="src/main/resources/assets/neonlyrics/font"
mkdir -p "$FONTDIR"
if curl -fsSL -m 90 -o /tmp/caveat.ttf "https://github.com/google/fonts/raw/main/ofl/caveat/Caveat%5Bwght%5D.ttf" \
   && [ "$(stat -c%s /tmp/caveat.ttf)" -gt 50000 ] \
   && [ "$(head -c4 /tmp/caveat.ttf | od -An -tx1 | tr -d ' \n')" = "00010000" ]; then
  cp /tmp/caveat.ttf "$FONTDIR/caveat.ttf"
  cat > "$FONTDIR/script.json" <<'JSON'
{
  "providers": [
    { "type": "ttf", "file": "neonlyrics:caveat.ttf", "size": 13.0, "oversample": 6.0, "shift": [0.0, 1.0] },
    { "type": "reference", "id": "minecraft:default" }
  ]
}
JSON
  echo "::notice title=Font::Handwritten font downloaded and bundled"
else
  echo "::warning title=Font::Could not download the handwritten font, it will look like the normal font"
fi

FS="src/main/java/com/neonlyrics/FontSupport.java"
cp "$FS" /tmp/FontSupport.real

n=0
while read -r GRADLE LOOM VARIANT; do
  [ -z "$GRADLE" ] && continue
  n=$((n+1))
  echo "=== Attempt $n: Gradle $GRADLE, Loom $LOOM, font code '$VARIANT' ==="
  if [ "$VARIANT" = "real" ]; then cp /tmp/FontSupport.real "$FS"; else cp "$ROOT/ci/variants/$VARIANT/FontSupport.java" "$FS"; fi
  DIST="$HOME/gradle-$GRADLE"
  if [ ! -d "$DIST" ]; then
    curl -sSL -o /tmp/g.zip "https://services.gradle.org/distributions/gradle-$GRADLE-bin.zip" && unzip -q -o /tmp/g.zip -d "$HOME"
  fi
  rm -rf build
  "$DIST/bin/gradle" build --no-daemon --stacktrace -Ploom_version="$LOOM" 2>&1 | tee "/tmp/build-$n.log"
  if [ "${PIPESTATUS[0]}" -eq 0 ]; then
    echo "::notice title=Minecraft $MC built::Gradle $GRADLE / Loom $LOOM / font code '$VARIANT'"
    exit 0
  fi
  ERR=$(grep -E "error:|What went wrong|Could not (resolve|find|get|apply)|Unsupported|not supported|cannot find symbol|does not exist" -A2 "/tmp/build-$n.log" \
        | grep -v "^--$" | head -14 | tr '\n' '|' | sed 's/%/%25/g' | cut -c1-1400)
  echo "::error title=Minecraft $MC attempt $n (Gradle $GRADLE, Loom $LOOM, font '$VARIANT') failed::$ERR"
done < "$ROOT/ci/$MC.txt"
echo "All attempts failed for $MC"
exit 1
