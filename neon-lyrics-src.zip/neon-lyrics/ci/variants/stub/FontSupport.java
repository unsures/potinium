package com.neonlyrics;

import net.minecraft.network.chat.MutableComponent;

/** Fallback #2: the Handwritten font is switched off (it looks like Normal) but everything else works. */
final class FontSupport {
    private FontSupport() {
    }

    static MutableComponent script(MutableComponent c) {
        return c;
    }
}
