package com.neonlyrics;

import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

/** Fallback #1: older style of setting a font. */
final class FontSupport {
    private FontSupport() {
    }

    static MutableComponent script(MutableComponent c) {
        return c.withStyle(Style.EMPTY.withFont(Identifier.fromNamespaceAndPath("neonlyrics", "script")));
    }
}
