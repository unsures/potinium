package com.neonlyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Audius (audius.co): a free, open music service. No account or key needed. */
public final class AudiusClient {
    private AudiusClient() {
    }

    private static final String API = "https://api.audius.co/v1";
    private static final String APP = "app_name=Potinium";
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10)).followRedirects(HttpClient.Redirect.ALWAYS).build();

    public static boolean isFree(Track t) {
        return t.id().startsWith("audius:") || t.id().startsWith("local:");
    }

    /** Empty query = what's trending right now. */
    public static CompletableFuture<List<Track>> search(String query) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String url = query.isBlank()
                        ? API + "/tracks/trending?limit=25&" + APP
                        : API + "/tracks/search?query=" + SpotifyClient.enc(query) + "&limit=25&" + APP;
                HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                        .header("User-Agent", "Potinium/1.0").timeout(Duration.ofSeconds(15)).GET().build();
                HttpResponse<String> r = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                if (r.statusCode() != 200) throw new IllegalStateException("Audius error " + r.statusCode());
                JsonArray data = JsonParser.parseString(r.body()).getAsJsonObject().getAsJsonArray("data");
                List<Track> out = new ArrayList<>();
                for (JsonElement e : data) {
                    JsonObject o = e.getAsJsonObject();
                    if (o.has("is_streamable") && !o.get("is_streamable").isJsonNull()
                            && !o.get("is_streamable").getAsBoolean()) continue;
                    String id = o.get("id").getAsString();
                    String title = o.has("title") ? o.get("title").getAsString() : "?";
                    String artist = "";
                    if (o.has("user") && o.get("user").isJsonObject() && o.getAsJsonObject("user").has("name")) {
                        artist = o.getAsJsonObject("user").get("name").getAsString();
                    }
                    long dur = o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsLong() * 1000L : 0;
                    out.add(new Track("audius:" + id, API + "/tracks/" + id + "/stream?" + APP, title, artist, "", dur));
                }
                return out;
            } catch (RuntimeException e) {
                throw e;
            } catch (Exception e) {
                throw new RuntimeException("Could not reach Audius: " + e.getMessage(), e);
            }
        });
    }

    public static java.io.InputStream open(Track t) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(t.uri()))
                .header("User-Agent", "Potinium/1.0").timeout(Duration.ofSeconds(30)).GET().build();
        HttpResponse<java.io.InputStream> r = HTTP.send(req, HttpResponse.BodyHandlers.ofInputStream());
        if (r.statusCode() != 200) throw new IllegalStateException("Audius stream error " + r.statusCode());
        return new java.io.BufferedInputStream(r.body(), 64 * 1024);
    }
}
