package com.neonlyrics;

import java.awt.Color;
import java.util.List;

/** Pure maths and helpers (no Minecraft classes), shared by every version. */
public final class LyricMath {
    private LyricMath() {
    }

    public static final String[] FONT_NAMES = {"Normal", "Bold", "Italic", "Bold Italic", "Underline", "UPPERCASE", "W I D E"};
    public static final String[] ANIM_NAMES = {"Fade", "Typewriter", "Wave", "Karaoke"};
    public static final String[] INTENSITY_NAMES = {"Normal", "Hype", "Chill"};
    public static final String[] PLACEMENT_NAMES = {"In front of you", "Scatter around you"};

    public static float speedMul(Config c) {
        return c.intensity == 1 ? 1.7f : c.intensity == 2 ? 0.6f : 1f;
    }

    public static float ampMul(Config c) {
        return c.intensity == 1 ? 1.6f : c.intensity == 2 ? 0.6f : 1f;
    }

    public static float fadeMul(Config c) {
        return c.intensity == 1 ? 0.6f : c.intensity == 2 ? 1.6f : 1f;
    }

    public static float glowMul(Config c) {
        return c.intensity == 1 ? 1.4f : c.intensity == 2 ? 0.8f : 1f;
    }

    public static float tiltDeg(Config c) {
        return c.intensity == 1 ? 26f : c.intensity == 2 ? 8f : 14f;
    }

    public static final String[] COLOR_NAMES = {"Cyan", "Hot Pink", "Lime", "Purple", "Orange", "Yellow", "White",
            "Red", "Blue", "Rainbow", "Custom"};
    private static final int[] COLORS = {0x00F6FF, 0xFF2BD6, 0x39FF14, 0xB04BFF, 0xFF9F1C, 0xFFE600, 0xFFFFFF,
            0xFF3B3B, 0x3D7BFF};

    public static boolean bold(int font) {
        return font == 1 || font == 3;
    }

    public static boolean italic(int font) {
        return font == 2 || font == 3;
    }

    public static boolean underline(int font) {
        return font == 4;
    }

    public static String transform(String s, int font) {
        if (font == 5) return s.toUpperCase();
        if (font == 6) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                char ch = s.charAt(i);
                sb.append(ch);
                if (ch != ' ' && i + 1 < s.length()) sb.append(' '); // hair space
            }
            return sb.toString();
        }
        return s;
    }

    public static int color(Config c, float timeSeconds) {
        int i = c.colorIndex;
        if (i < COLORS.length) return COLORS[Math.max(0, i)];
        if (i == COLORS.length) return Color.HSBtoRGB((timeSeconds * 0.1f) % 1f, 0.75f, 1f) & 0xFFFFFF;
        return (clamp255(c.customR) << 16) | (clamp255(c.customG) << 8) | clamp255(c.customB);
    }

    public static int clamp255(int v) {
        return Math.max(0, Math.min(255, v));
    }

    public static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** ARGB with the alpha clamped so vanilla never treats it as "opaque by accident". */
    public static int argb(float alpha, int rgb) {
        int a = Math.round(Math.max(0f, Math.min(1f, alpha)) * 255f);
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    /** What to show right now: the text, its visibility, and when the line starts and ends. */
    public record Frame(String text, float alpha, float outAlpha, int index, long startMs, long endMs) {
        public static final Frame EMPTY = new Frame("", 0f, 0f, -1, 0, 0);
    }

    private static final long MAX_HOLD_MS = 7000;

    private static float smooth(float a) {
        a = Math.max(0f, Math.min(1f, a));
        return a * a * (3f - 2f * a);
    }

    public static Frame frame(List<LyricsService.Line> lines, long posMs, Config c, long songLenMs) {
        int idx = LyricsService.indexAt(lines, posMs);
        if (idx < 0) return Frame.EMPTY;
        LyricsService.Line cur = lines.get(idx);
        long start = cur.timeMs();
        long end;
        if (idx + 1 < lines.size()) end = lines.get(idx + 1).timeMs();
        else end = songLenMs > start ? songLenMs : start + MAX_HOLD_MS;
        end = Math.min(end, start + MAX_HOLD_MS);
        if (cur.text().isBlank()) return new Frame("", 0f, 0f, idx, start, end);
        long dur = Math.max(1, end - start);

        float m = fadeMul(c);
        float fin = Math.min(c.fadeInMs * m, dur * 0.4f);
        float fout = Math.min(c.fadeOutMs * m, dur * 0.4f);
        float inA = 1f, outA = 1f;
        if (fin > 0) inA = smooth((posMs - start) / fin);
        if (fout > 0) outA = smooth((end - posMs) / fout);
        if (posMs >= end) outA = 0f;
        return new Frame(cur.text(), Math.min(inA, outA), outA, idx, start, end);
    }

    /** Pixel position of a world point on screen. Returns null when it is behind the camera. */
    public static float[] project(double dx, double dy, double dz, float yawDeg, float pitchDeg,
                                  float fovDeg, int screenW, int screenH) {
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        double fx = -Math.sin(yaw) * Math.cos(pitch);
        double fy = -Math.sin(pitch);
        double fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy;
        double uy = rz * fx - rx * fz;
        double uz = rx * fy - ry * fx;
        double depth = dx * fx + dy * fy + dz * fz;
        if (depth < 0.5) return null;
        double right = dx * rx + dy * ry + dz * rz;
        double up = dx * ux + dy * uy + dz * uz;
        double focal = (screenH / 2.0) / Math.tan(Math.toRadians(fovDeg) / 2.0);
        float sx = (float) (screenW / 2.0 + right / depth * focal);
        float sy = (float) (screenH / 2.0 - up / depth * focal);
        return new float[]{sx, sy, (float) (focal / depth)};
    }
}
