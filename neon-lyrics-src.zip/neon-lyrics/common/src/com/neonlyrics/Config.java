package com.neonlyrics;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Saved to config/neonlyrics.json */
public class Config {
    public String clientId = "";

    // ---- world lyrics (floating in the 3D world)
    public boolean showWorld = true;
    /** Distance from you in blocks. Small = near you, large = far away. */
    public float distance = 14f;
    /** Height above your eyes in blocks. Large = up in the sky. */
    public float height = 3f;
    public float worldScale = 1f;
    public boolean followCamera = true;

    // ---- screen lyrics (flat on your screen)
    public boolean showScreen = true;
    public float screenScale = 1.5f;
    /** 0 = rounded karaoke bar at the top, 1 = floating neon text. */
    public int screenStyle = 0;
    /** Vertical position of the on-screen lyrics, percent of screen height from the top. */
    public int screenYPercent = 4;

    // ---- style
    public int fontIndex = 0;
    public int colorIndex = 3;
    public int customR = 255, customG = 80, customB = 200;
    public int fadeInMs = 350;
    public int fadeOutMs = 450;
    public int lyricOffsetMs = 0;
    /** 1.00 = normal. Below 1 for slowed songs, above 1 for sped-up songs. */
    public float lyricSpeed = 1f;

    // ---- placement / motion
    /** 0 = in front of you, 1 = scattered around you (fixed in the world). */
    public int placement = 0;
    public boolean rotate = false;
    /** How far left/right (degrees) scattered lines may appear from where you were looking. */
    public int spread = 40;
    /** Scatter words appear this many blocks away (near you) and this big. */
    public float scatterDistance = 6f;
    public float scatterScale = 3f;
    /** 0 Fade, 1 Typewriter, 2 Wave, 3 Karaoke */
    public int animation = 0;
    /** 0 Normal, 1 Hype, 2 Chill */
    public int intensity = 0;

    // ---- misc
    public boolean autoOpenOnJoin = true;
    /** Volume of the in-game music player, 0-100. */
    public int musicVolume = 60;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("neonlyrics.json");
    }

    public static Config load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Config c = GSON.fromJson(Files.readString(p), Config.class);
                if (c != null) return c;
            }
        } catch (Exception e) {
            NeonLyricsClient.LOGGER.warn("Could not read config, using defaults", e);
        }
        Config c = new Config();
        c.save();
        return c;
    }

    public void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (Exception e) {
            NeonLyricsClient.LOGGER.warn("Could not save config", e);
        }
    }
}
