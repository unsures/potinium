package com.neonlyrics;

public record PlaybackState(Track track, boolean playing, long progressMs, long fetchedNanos) {
    public static final PlaybackState NONE = new PlaybackState(null, false, 0, 0);

    /** Smoothly estimated playback position between Spotify polls. */
    public long positionMs() {
        if (track == null) return 0;
        long p = progressMs;
        if (playing) p += (System.nanoTime() - fetchedNanos) / 1_000_000L;
        if (track.durationMs() > 0) p = Math.min(p, track.durationMs());
        return Math.max(0, p);
    }
}
