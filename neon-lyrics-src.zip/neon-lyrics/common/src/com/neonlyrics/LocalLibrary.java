package com.neonlyrics;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** MP3 files you put in the "potinium_music" folder inside your Minecraft folder. Name them "Artist - Title.mp3". */
public final class LocalLibrary {
    private LocalLibrary() {
    }

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("potinium_music");
    }

    public static List<Track> list() {
        List<Track> out = new ArrayList<>();
        try {
            Files.createDirectories(dir());
            try (Stream<Path> s = Files.list(dir())) {
                s.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".mp3")).sorted().forEach(p -> {
                    String file = p.getFileName().toString();
                    String base = file.substring(0, file.length() - 4);
                    String artist = "";
                    String title = base;
                    int i = base.indexOf(" - ");
                    if (i > 0) {
                        artist = base.substring(0, i).trim();
                        title = base.substring(i + 3).trim();
                    }
                    out.add(new Track("local:" + file, p.toString(), title, artist, "", 0));
                });
            }
        } catch (Exception e) {
            NeonLyricsClient.LOGGER.warn("Could not list local music: {}", e.toString());
        }
        return out;
    }

    /** Length of an mp3 in milliseconds (reads the frame headers). */
    public static long durationMs(Path p) {
        try (java.io.InputStream in = new java.io.BufferedInputStream(Files.newInputStream(p), 64 * 1024)) {
            javazoom.jl.decoder.Bitstream bs = new javazoom.jl.decoder.Bitstream(in);
            double ms = 0;
            javazoom.jl.decoder.Header h;
            while ((h = bs.readFrame()) != null) {
                ms += h.ms_per_frame();
                bs.closeFrame();
            }
            return Math.round(ms);
        } catch (Throwable t) {
            return 0;
        }
    }
}
