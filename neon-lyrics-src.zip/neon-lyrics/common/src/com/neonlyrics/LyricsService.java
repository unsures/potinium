package com.neonlyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Spotify's API does not expose lyrics, so synced lyrics are fetched from the free LRCLIB service
 * (https://lrclib.net) using the track name, artist, album and duration.
 */
public final class LyricsService {
    public record Line(long timeMs, String text) {
    }

    private static final Pattern STAMP = Pattern.compile("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]");

    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();

    private volatile List<Line> lines = List.of();
    private volatile String status = "";
    private volatile String currentId = "";

    public List<Line> lines() {
        return lines;
    }

    public String status() {
        return status;
    }

    public void onTrack(Track t) {
        currentId = t.id();
        lines = List.of();
        status = "Finding lyrics...";
        Thread th = new Thread(() -> fetch(t), "NeonLyrics-Lyrics");
        th.setDaemon(true);
        th.start();
    }

    private void fetch(Track t) {
        try {
            String synced = getExact(t);
            if (synced == null) synced = search(t);
            if (!currentId.equals(t.id())) return; // song changed while we were fetching
            if (synced == null || synced.isBlank()) {
                status = "No synced lyrics found";
                return;
            }
            List<Line> parsed = parse(synced);
            lines = parsed;
            status = parsed.isEmpty() ? "No synced lyrics found" : "";
        } catch (Exception e) {
            NeonLyricsClient.LOGGER.warn("Lyrics fetch failed: {}", e.toString());
            if (currentId.equals(t.id())) status = "Lyrics lookup failed";
        }
    }

    private String getExact(Track t) throws Exception {
        String url = "https://lrclib.net/api/get?track_name=" + SpotifyClient.enc(t.name())
                + "&artist_name=" + SpotifyClient.enc(firstArtist(t.artist()))
                + "&album_name=" + SpotifyClient.enc(t.album())
                + "&duration=" + Math.round(t.durationMs() / 1000.0);
        HttpResponse<String> r = send(url);
        if (r.statusCode() != 200) return null;
        JsonObject o = JsonParser.parseString(r.body()).getAsJsonObject();
        return text(o, "syncedLyrics");
    }

    private String search(Track t) throws Exception {
        String url = "https://lrclib.net/api/search?track_name=" + SpotifyClient.enc(t.name())
                + "&artist_name=" + SpotifyClient.enc(firstArtist(t.artist()));
        HttpResponse<String> r = send(url);
        if (r.statusCode() != 200) return null;
        JsonArray arr = JsonParser.parseString(r.body()).getAsJsonArray();
        String best = null;
        double bestDiff = Double.MAX_VALUE;
        for (JsonElement e : arr) {
            JsonObject o = e.getAsJsonObject();
            String s = text(o, "syncedLyrics");
            if (s == null || s.isBlank()) continue;
            double dur = o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsDouble() : 0;
            double diff = Math.abs(dur - t.durationMs() / 1000.0);
            if (diff < bestDiff) {
                bestDiff = diff;
                best = s;
            }
        }
        return best;
    }

    private HttpResponse<String> send(String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .header("User-Agent", "NeonLyricsMod/1.0 (Minecraft Fabric mod)")
                .timeout(Duration.ofSeconds(10)).GET().build();
        return http.send(req, HttpResponse.BodyHandlers.ofString());
    }

    private static String firstArtist(String artists) {
        int i = artists.indexOf(',');
        return i > 0 ? artists.substring(0, i) : artists;
    }

    private static String text(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : null;
    }

    static List<Line> parse(String lrc) {
        List<Line> out = new ArrayList<>();
        for (String raw : lrc.split("\\R")) {
            Matcher m = STAMP.matcher(raw);
            List<Long> times = new ArrayList<>();
            int end = 0;
            while (m.find() && m.start() == end) {
                long min = Long.parseLong(m.group(1));
                long sec = Long.parseLong(m.group(2));
                long ms = 0;
                if (m.group(3) != null) ms = Long.parseLong((m.group(3) + "00").substring(0, 3));
                times.add(min * 60_000L + sec * 1000L + ms);
                end = m.end();
            }
            if (times.isEmpty()) continue;
            String text = raw.substring(end).trim();
            for (long tm : times) out.add(new Line(tm, text));
        }
        out.sort((a, b) -> Long.compare(a.timeMs(), b.timeMs()));
        return out;
    }

    /** Index of the line that should be showing at the given position, or -1 before the first line. */
    public static int indexAt(List<Line> lines, long posMs) {
        int lo = 0, hi = lines.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).timeMs() <= posMs) {
                ans = mid;
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        return ans;
    }
}
