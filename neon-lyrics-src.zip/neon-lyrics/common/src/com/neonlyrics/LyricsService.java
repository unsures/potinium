package com.neonlyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.CompletableFuture;

/**
 * Spotify's API does not expose lyrics, so synced lyrics are fetched from the free LRCLIB service
 * (https://lrclib.net) using the track name, artist, album and duration.
 */
public final class LyricsService {
    public record Line(long timeMs, String text) {
    }

    private static final Pattern STAMP = Pattern.compile("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]");

    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();

    private volatile List<Line> lines = List.of();
    private volatile String status = "";
    private volatile String currentId = "";

    public List<Line> lines() {
        return lines;
    }

    public String status() {
        return status;
    }

    public void onTrack(Track t) {
        currentId = t.id();
        lines = List.of();
        status = "Finding lyrics...";
        Thread th = new Thread(() -> fetch(t), "NeonLyrics-Lyrics");
        th.setDaemon(true);
        th.start();
    }

    private void fetch(Track t) {
        try {
            String artist = firstArtist(t.artist());
            String clean = cleanTitle(t.name());
            String synced = getExact(t.name(), artist, t.album(), t.durationMs());
            if (synced == null && !clean.equals(t.name())) synced = getExact(clean, artist, t.album(), t.durationMs());
            if (synced == null) synced = getExact(clean, artist, "", t.durationMs());
            if (synced == null) synced = search("track_name=" + SpotifyClient.enc(clean)
                    + "&artist_name=" + SpotifyClient.enc(artist), t.durationMs());
            if (synced == null) synced = search("q=" + SpotifyClient.enc(clean + " " + artist), t.durationMs());
            if (synced == null) synced = search("q=" + SpotifyClient.enc(clean), t.durationMs());
            if (!currentId.equals(t.id())) return; // song changed while we were fetching
            if (synced == null || synced.isBlank()) {
                status = "No synced lyrics found on lrclib.net";
                return;
            }
            List<Line> parsed = parse(synced);
            lines = parsed;
            status = parsed.isEmpty() ? "No synced lyrics found on lrclib.net" : "";
        } catch (Exception e) {
            NeonLyricsClient.LOGGER.warn("Lyrics fetch failed: {}", e.toString());
            if (currentId.equals(t.id())) status = "Lyrics lookup failed (check internet)";
        }
    }

    /** "Song (feat. X) - Remastered 2011" -> "Song" */
    static String cleanTitle(String name) {
        String s = name.replaceAll("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]", "");
        s = s.replaceAll("(?i)\\s+-\\s+(remaster(ed)?|live|mono|stereo|single|radio|acoustic|version|edit|deluxe|bonus|\\d{4}).*$", "");
        s = s.trim();
        return s.isEmpty() ? name : s;
    }

    private String getExact(String title, String artist, String album, long durationMs) throws Exception {
        String url = "https://lrclib.net/api/get?track_name=" + SpotifyClient.enc(title)
                + "&artist_name=" + SpotifyClient.enc(artist)
                + (album.isEmpty() ? "" : "&album_name=" + SpotifyClient.enc(album))
                + "&duration=" + Math.round(durationMs / 1000.0);
        HttpResponse<String> r = send(url);
        if (r.statusCode() != 200) return null;
        JsonObject o = JsonParser.parseString(r.body()).getAsJsonObject();
        String s = text(o, "syncedLyrics");
        return s == null || s.isBlank() ? null : s;
    }

    private String search(String query, long durationMs) throws Exception {
        HttpResponse<String> r = send("https://lrclib.net/api/search?" + query);
        if (r.statusCode() != 200) return null;
        JsonArray arr = JsonParser.parseString(r.body()).getAsJsonArray();
        String best = null;
        double bestDiff = Double.MAX_VALUE;
        for (JsonElement e : arr) {
            JsonObject o = e.getAsJsonObject();
            String s = text(o, "syncedLyrics");
            if (s == null || s.isBlank()) continue;
            double dur = o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsDouble() : 0;
            double diff = Math.abs(dur - durationMs / 1000.0);
            if (diff < bestDiff) {
                bestDiff = diff;
                best = s;
            }
        }
        // a result that is wildly different in length is probably a different song
        return bestDiff <= 12 ? best : null;
    }

    /** A song found directly on lrclib.net (used when Spotify can't be reached). */
    public record Result(Track track, String synced) {
    }

    public CompletableFuture<List<Result>> searchAll(String q) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<String> r = send("https://lrclib.net/api/search?q=" + SpotifyClient.enc(q));
                if (r.statusCode() != 200) throw new IllegalStateException("lrclib.net error " + r.statusCode());
                List<Result> out = new ArrayList<>();
                for (JsonElement e : JsonParser.parseString(r.body()).getAsJsonArray()) {
                    JsonObject o = e.getAsJsonObject();
                    String synced = text(o, "syncedLyrics");
                    if (synced == null || synced.isBlank()) continue;
                    double dur = o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsDouble() : 0;
                    String id = "lrclib:" + (o.has("id") ? o.get("id").getAsString() : String.valueOf(out.size()));
                    String name = text(o, "trackName") == null ? "?" : text(o, "trackName");
                    String artist = text(o, "artistName") == null ? "" : text(o, "artistName");
                    String album = text(o, "albumName") == null ? "" : text(o, "albumName");
                    out.add(new Result(new Track(id, "", name, artist, album, Math.round(dur * 1000)), synced));
                }
                return out;
            } catch (RuntimeException e) {
                throw e;
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage(), e);
            }
        });
    }

    public void showManual(Result res) {
        currentId = res.track().id();
        lines = parse(res.synced());
        status = lines.isEmpty() ? "No synced lyrics found on lrclib.net" : "";
    }

    private HttpResponse<String> send(String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .header("User-Agent", "NeonLyricsMod/1.0 (Minecraft Fabric mod)")
                .timeout(Duration.ofSeconds(10)).GET().build();
        return http.send(req, HttpResponse.BodyHandlers.ofString());
    }

    private static String firstArtist(String artists) {
        int i = artists.indexOf(',');
        return i > 0 ? artists.substring(0, i) : artists;
    }

    private static String text(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : null;
    }

    static List<Line> parse(String lrc) {
        List<Line> out = new ArrayList<>();
        for (String raw : lrc.split("\\R")) {
            Matcher m = STAMP.matcher(raw);
            List<Long> times = new ArrayList<>();
            int end = 0;
            while (m.find() && m.start() == end) {
                long min = Long.parseLong(m.group(1));
                long sec = Long.parseLong(m.group(2));
                long ms = 0;
                if (m.group(3) != null) ms = Long.parseLong((m.group(3) + "00").substring(0, 3));
                times.add(min * 60_000L + sec * 1000L + ms);
                end = m.end();
            }
            if (times.isEmpty()) continue;
            String text = raw.substring(end).trim();
            for (long tm : times) out.add(new Line(tm, text));
        }
        out.sort((a, b) -> Long.compare(a.timeMs(), b.timeMs()));
        return out;
    }

    /** Index of the line that should be showing at the given position, or -1 before the first line. */
    public static int indexAt(List<Line> lines, long posMs) {
        int lo = 0, hi = lines.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).timeMs() <= posMs) {
                ans = mid;
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        return ans;
    }
}
