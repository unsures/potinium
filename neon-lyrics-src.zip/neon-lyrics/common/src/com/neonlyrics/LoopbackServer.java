package com.neonlyrics;

import com.sun.net.httpserver.HttpServer;

import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.function.Function;

/** Tiny local web server that catches Spotify's redirect. Kept separate so a missing JDK module can't break the mod. */
final class LoopbackServer {
    private final HttpServer server;

    private LoopbackServer(HttpServer server) {
        this.server = server;
    }

    static LoopbackServer start(Function<String, String> onRedirect) throws Exception {
        HttpServer s = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 8888), 0);
        LoopbackServer wrapper = new LoopbackServer(s);
        s.createContext("/callback", ex -> {
            String msg;
            try {
                msg = onRedirect.apply(ex.getRequestURI().getRawQuery());
            } catch (Exception e) {
                msg = "Something went wrong: " + e.getMessage();
            }
            byte[] body = ("<html><head><meta name='viewport' content='width=device-width'></head>"
                    + "<body style='font-family:sans-serif;background:#111;color:#0ff;text-align:center;padding-top:80px'>"
                    + "<h2>" + msg + "</h2></body></html>").getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
            ex.sendResponseHeaders(200, body.length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(body);
            }
            Thread t = new Thread(() -> {
                try {
                    Thread.sleep(800);
                } catch (InterruptedException ignored) {
                }
                wrapper.stop();
            });
            t.setDaemon(true);
            t.start();
        });
        s.start();
        return wrapper;
    }

    void stop() {
        try {
            server.stop(0);
        } catch (Throwable ignored) {
        }
    }
}
