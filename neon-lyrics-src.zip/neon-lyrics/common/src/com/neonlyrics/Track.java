package com.neonlyrics;

public record Track(String id, String uri, String name, String artist, String album, long durationMs) {
}
