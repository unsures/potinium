package com.neonlyrics;

import java.util.ArrayList;
import java.util.List;

/** The mod's own song queue. When a song ends, the next queued song starts (and its lyrics with it). */
public final class SongQueue {
    private SongQueue() {
    }

    /** synced = lyrics already known (songs found through the Lyrics tab); otherwise they are looked up when played. */
    public record Entry(Track track, String synced) {
    }

    private static final List<Entry> LIST = new ArrayList<>();
    private static long cooldownUntil;

    public static synchronized List<Entry> snapshot() {
        return new ArrayList<>(LIST);
    }

    public static synchronized int size() {
        return LIST.size();
    }

    public static synchronized void add(Entry e) {
        LIST.add(e);
    }

    public static synchronized void remove(int i) {
        if (i >= 0 && i < LIST.size()) LIST.remove(i);
    }

    public static synchronized void clear() {
        LIST.clear();
    }

    private static synchronized Entry pollFirst() {
        return LIST.isEmpty() ? null : LIST.remove(0);
    }

    /** Starts this song right now. */
    public static void playNow(Entry e) {
        SpotifyClient sp = SpotifyClient.get();
        Track t = e.track();
        if (e.synced() != null || sp.isManual() || !sp.isLoggedIn()) {
            sp.startManual(t, true);
            if (e.synced() != null) NeonLyricsClient.LYRICS.showManual(new LyricsService.Result(t, e.synced()));
            else NeonLyricsClient.LYRICS.onTrack(t);
        } else {
            sp.playTracks(List.of(t), 0);
        }
        cooldownUntil = System.currentTimeMillis() + 4000;
    }

    /** Called every client tick: moves on to the next queued song when the current one has finished. */
    public static void tick() {
        long now = System.currentTimeMillis();
        if (now < cooldownUntil || size() == 0) return;
        PlaybackState s = SpotifyClient.get().state();
        Track t = s.track();
        if (t == null || !s.playing() || t.durationMs() <= 0) return;
        if (s.positionMs() >= t.durationMs() - 250) {
            Entry next = pollFirst();
            if (next != null) playNow(next);
        }
    }
}
