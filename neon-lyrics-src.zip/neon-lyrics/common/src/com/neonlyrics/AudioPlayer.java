package com.neonlyrics;

import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.AL11;
import org.lwjgl.openal.ALC10;

import java.io.InputStream;
import java.nio.ShortBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Plays music inside Minecraft (Audius or local mp3 files). Because the mod itself plays the audio, the
 * lyrics clock is the real playback position, so lyrics are always in sync with no manual timing.
 */
public final class AudioPlayer {
    private static final AudioPlayer INSTANCE = new AudioPlayer();

    public static AudioPlayer get() {
        return INSTANCE;
    }

    private final AtomicInteger generation = new AtomicInteger();
    private volatile boolean paused;
    private volatile boolean active;
    private volatile Track track;
    public volatile String status = "";

    private AudioPlayer() {
    }

    public boolean isActive() {
        return active;
    }

    public void toggle() {
        paused = !paused;
    }

    public void restart() {
        Track t = track;
        if (t != null) play(t);
    }

    public void stop() {
        generation.incrementAndGet();
        active = false;
    }

    public void play(Track t) {
        final int gen = generation.incrementAndGet();
        active = true;
        paused = false;
        track = t;
        status = "Loading " + t.name() + "...";
        SpotifyClient.get().external(new PlaybackState(t, false, 0, System.nanoTime()));
        Thread th = new Thread(() -> run(t, gen), "Potinium-Audio");
        th.setDaemon(true);
        th.start();
    }

    private static float gain() {
        Config c = NeonLyricsClient.CONFIG;
        return c == null ? 0.6f : Math.max(0f, Math.min(1f, c.musicVolume / 100f));
    }

    private void publish(Track t, boolean playing, long posMs) {
        SpotifyClient.get().external(new PlaybackState(t, playing, posMs, System.nanoTime()));
    }

    private void run(Track original, int gen) {
        Track t = original;
        int source = 0;
        int[] bufs = new int[6];
        InputStream in = null;
        try {
            if (ALC10.alcGetCurrentContext() == 0) {
                throw new IllegalStateException("Minecraft sound is off. Turn the game's Master volume on.");
            }
            if (t.id().startsWith("local:")) {
                Path p = Path.of(t.uri());
                if (t.durationMs() <= 0) {
                    t = new Track(t.id(), t.uri(), t.name(), t.artist(), t.album(), LocalLibrary.durationMs(p));
                    track = t;
                }
                in = new java.io.BufferedInputStream(Files.newInputStream(p), 64 * 1024);
            } else {
                in = AudiusClient.open(t);
            }
            NeonLyricsClient.LYRICS.onTrack(t);

            Bitstream bs = new Bitstream(in);
            Decoder dec = new Decoder();
            source = AL10.alGenSources();
            ArrayDeque<Integer> free = new ArrayDeque<>();
            Map<Integer, Integer> frames = new HashMap<>();
            for (int i = 0; i < bufs.length; i++) {
                bufs[i] = AL10.alGenBuffers();
                free.add(bufs[i]);
            }
            long processed = 0;
            int rate = 0, channels = 2;
            boolean eof = false;
            short[] acc = new short[8 * 1152 * 2];

            while (generation.get() == gen) {
                AL10.alSourcef(source, AL10.AL_GAIN, gain());

                int done = AL10.alGetSourcei(source, AL10.AL_BUFFERS_PROCESSED);
                while (done-- > 0) {
                    int b = AL10.alSourceUnqueueBuffers(source);
                    processed += frames.getOrDefault(b, 0);
                    free.add(b);
                }

                while (!free.isEmpty() && !eof) {
                    int accLen = 0;
                    for (int k = 0; k < 8; k++) {
                        Header h = bs.readFrame();
                        if (h == null) {
                            eof = true;
                            break;
                        }
                        SampleBuffer sb = (SampleBuffer) dec.decodeFrame(h, bs);
                        bs.closeFrame();
                        if (rate == 0) {
                            rate = sb.getSampleFrequency();
                            channels = sb.getChannelCount();
                        }
                        int len = sb.getBufferLength();
                        if (accLen + len > acc.length) acc = java.util.Arrays.copyOf(acc, (accLen + len) * 2);
                        System.arraycopy(sb.getBuffer(), 0, acc, accLen, len);
                        accLen += len;
                    }
                    if (accLen > 0) {
                        ShortBuffer sbuf = BufferUtils.createShortBuffer(accLen);
                        sbuf.put(acc, 0, accLen).flip();
                        int b = free.poll();
                        AL10.alBufferData(b, channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, sbuf, rate);
                        AL10.alSourceQueueBuffers(source, b);
                        frames.put(b, accLen / Math.max(1, channels));
                    }
                }

                int queued = AL10.alGetSourcei(source, AL10.AL_BUFFERS_QUEUED);
                int state = AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE);
                if (paused) {
                    if (state == AL10.AL_PLAYING) AL10.alSourcePause(source);
                } else if (state != AL10.AL_PLAYING && queued > 0) {
                    AL10.alSourcePlay(source);
                }

                long posFrames = processed + AL10.alGetSourcei(source, AL11.AL_SAMPLE_OFFSET);
                long posMs = rate > 0 ? posFrames * 1000L / rate : 0;
                if (status.startsWith("Loading") && rate > 0) status = "";
                publish(t, !paused && rate > 0, posMs);

                if (eof && queued == 0) { // finished
                    Track end = new Track(t.id(), t.uri(), t.name(), t.artist(), t.album(), posMs);
                    publish(end, SongQueue.size() > 0, posMs);
                    active = false;
                    break;
                }
                Thread.sleep(15);
            }
        } catch (Throwable e) {
            NeonLyricsClient.LOGGER.warn("Audio playback failed", e);
            if (generation.get() == gen) {
                status = "Could not play: " + (e.getMessage() == null ? e.toString() : e.getMessage());
                active = false;
            }
        } finally {
            try {
                if (source != 0) {
                    AL10.alSourceStop(source);
                    int q = AL10.alGetSourcei(source, AL10.AL_BUFFERS_QUEUED);
                    while (q-- > 0) AL10.alSourceUnqueueBuffers(source);
                    AL10.alDeleteSources(source);
                }
                for (int b : bufs) if (b != 0) AL10.alDeleteBuffers(b);
            } catch (Throwable ignored) {
            }
            try {
                if (in != null) in.close();
            } catch (Throwable ignored) {
            }
        }
    }
}
