package com.neonlyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Spotify Web API access using the Authorization Code + PKCE flow (no client secret needed).
 * Redirect URI that must be registered in your Spotify app: http://127.0.0.1:8888/callback
 */
public final class SpotifyClient {
    private static final SpotifyClient INSTANCE = new SpotifyClient();

    public static SpotifyClient get() {
        return INSTANCE;
    }

    public static final String REDIRECT_URI = "http://127.0.0.1:8888/callback";
    private static final String API = "https://api.spotify.com/v1";
    private static final String SCOPES = "user-read-playback-state user-modify-playback-state "
            + "user-read-currently-playing playlist-read-private playlist-read-collaborative user-library-read";

    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private final ExecutorService pool = Executors.newFixedThreadPool(3, r -> {
        Thread t = new Thread(r, "NeonLyrics-Net");
        t.setDaemon(true);
        return t;
    });
    private ScheduledExecutorService poller;

    private volatile String accessToken;
    private volatile String refreshToken;
    private volatile long expiresAtMs;
    private volatile PlaybackState state = PlaybackState.NONE;
    private volatile String lastTrackId = "";

    private LoopbackServer server;
    public volatile String loginMessage = "";
    public volatile boolean loopbackActive;
    private String verifier;
    private String oauthState;

    private SpotifyClient() {
    }

    // ---------------------------------------------------------------- state

    // ---- "lyrics only" mode: no Spotify connection, the mod keeps its own play clock
    private volatile boolean manual;

    public boolean isManual() {
        return manual;
    }

    /** Starts a paused clock for a song picked from lrclib.net. */
    public void startManual(Track t) {
        startManual(t, false);
    }

    public void startManual(Track t, boolean playing) {
        manual = true;
        lastTrackId = t.id();
        state = new PlaybackState(t, playing, 0, System.nanoTime());
    }

    /** Used by the in-game audio player to report what it is playing. */
    public void external(PlaybackState s) {
        manual = true;
        lastTrackId = s.track() == null ? "" : s.track().id();
        state = s;
    }

    public void manualToggle() {
        if (AudioPlayer.get().isActive()) {
            AudioPlayer.get().toggle();
            return;
        }
        PlaybackState s = state;
        if (s.track() == null) return;
        state = new PlaybackState(s.track(), !s.playing(), s.positionMs(), System.nanoTime());
    }

    public void manualSeek(long deltaMs) {
        if (AudioPlayer.get().isActive()) {
            if (deltaMs < 0) AudioPlayer.get().restart();
            else SongQueue.skip();
            return;
        }
        PlaybackState s = state;
        if (s.track() == null) return;
        state = new PlaybackState(s.track(), s.playing(), Math.max(0, s.positionMs() + deltaMs), System.nanoTime());
    }

    public PlaybackState state() {
        return state;
    }

    public boolean isLoggedIn() {
        return refreshToken != null;
    }

    private static Path tokenFile() {
        return FabricLoader.getInstance().getConfigDir().resolve("neonlyrics_spotify.json");
    }

    /** Call once at startup: loads saved login and starts polling. */
    public void init() {
        try {
            Path p = tokenFile();
            if (Files.exists(p)) {
                JsonObject o = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
                if (o.has("refresh_token")) refreshToken = o.get("refresh_token").getAsString();
            }
        } catch (Exception e) {
            NeonLyricsClient.LOGGER.warn("Could not load Spotify tokens", e);
        }
        if (isLoggedIn()) startPolling();
    }

    private void saveTokens() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("refresh_token", refreshToken);
            Files.writeString(tokenFile(), o.toString());
        } catch (Exception e) {
            NeonLyricsClient.LOGGER.warn("Could not save Spotify tokens", e);
        }
    }

    public void logout() {
        accessToken = null;
        refreshToken = null;
        state = PlaybackState.NONE;
        try {
            Files.deleteIfExists(tokenFile());
        } catch (Exception ignored) {
        }
        if (poller != null) {
            poller.shutdownNow();
            poller = null;
        }
    }

    // ---------------------------------------------------------------- login

    /**
     * Prepares the login and returns the Spotify URL to open in a browser. Tries to start a tiny local
     * server that catches the redirect; if that is impossible on this device, the player can paste the
     * redirected address instead (see finishLoginFromUrl).
     */
    public synchronized String beginLogin(String clientId) throws Exception {
        if (server != null) {
            server.stop();
            server = null;
        }
        loginMessage = "";
        byte[] rnd = new byte[64];
        SecureRandom sr = new SecureRandom();
        sr.nextBytes(rnd);
        verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(rnd);
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII));
        String challenge = Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        byte[] st = new byte[16];
        sr.nextBytes(st);
        oauthState = Base64.getUrlEncoder().withoutPadding().encodeToString(st);
        pendingClientId = clientId;

        loopbackActive = false;
        try {
            server = LoopbackServer.start(this::onRedirect);
            loopbackActive = true;
        } catch (Throwable t) {
            NeonLyricsClient.LOGGER.warn("Local login server unavailable, paste mode will be used: {}", t.toString());
        }

        return "https://accounts.spotify.com/authorize?response_type=code"
                + "&client_id=" + enc(clientId)
                + "&scope=" + enc(SCOPES)
                + "&redirect_uri=" + enc(REDIRECT_URI)
                + "&state=" + enc(oauthState)
                + "&code_challenge_method=S256&code_challenge=" + enc(challenge);
    }

    private String pendingClientId;

    /** Called with the raw query string of the redirect. Returns the message to show in the browser. */
    String onRedirect(String rawQuery) {
        Map<String, String> q = parseQuery(rawQuery);
        String code = q.get("code");
        if (code != null && oauthState != null && oauthState.equals(q.get("state"))) {
            pool.submit(() -> {
                try {
                    exchangeCode(pendingClientId, code);
                    loginMessage = "Spotify linked!";
                } catch (Exception e) {
                    loginMessage = "Login failed: " + e.getMessage();
                    NeonLyricsClient.LOGGER.error("Spotify login failed", e);
                }
            });
            return "Spotify linked! You can close this tab and go back to Minecraft.";
        }
        return "Spotify login failed: " + q.getOrDefault("error", "unknown error");
    }

    /** Paste mode: the player copies the address of the page the browser ended on (it starts with 127.0.0.1). */
    public void finishLoginFromUrl(String url) {
        try {
            int i = url.indexOf('?');
            if (i < 0) throw new IllegalArgumentException("That address has no code in it");
            String msg = onRedirect(url.substring(i + 1).replaceAll("#.*$", ""));
            loginMessage = msg.startsWith("Spotify linked") ? "Linking..." : msg;
        } catch (Exception e) {
            loginMessage = "Could not read that address: " + e.getMessage();
        }
    }

    private void exchangeCode(String clientId, String code) throws Exception {
        Map<String, String> f = new LinkedHashMap<>();
        f.put("client_id", clientId);
        f.put("grant_type", "authorization_code");
        f.put("code", code);
        f.put("redirect_uri", REDIRECT_URI);
        f.put("code_verifier", verifier);
        applyTokenResponse(postForm(f));
        startPolling();
    }

    private synchronized void refresh() throws Exception {
        if (System.currentTimeMillis() < expiresAtMs - 30_000 && accessToken != null) return;
        if (refreshToken == null) throw new IllegalStateException("Not linked to Spotify");
        Map<String, String> f = new LinkedHashMap<>();
        f.put("client_id", NeonLyricsClient.CONFIG.clientId);
        f.put("grant_type", "refresh_token");
        f.put("refresh_token", refreshToken);
        applyTokenResponse(postForm(f));
    }

    private void applyTokenResponse(JsonObject o) {
        if (!o.has("access_token")) {
            throw new IllegalStateException("Spotify token error: " + o);
        }
        accessToken = o.get("access_token").getAsString();
        if (o.has("refresh_token")) refreshToken = o.get("refresh_token").getAsString();
        expiresAtMs = System.currentTimeMillis() + o.get("expires_in").getAsLong() * 1000L;
        saveTokens();
    }

    private JsonObject postForm(Map<String, String> form) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (var e : form.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
        }
        HttpRequest req = HttpRequest.newBuilder(URI.create("https://accounts.spotify.com/api/token"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .timeout(Duration.ofSeconds(15))
                .POST(HttpRequest.BodyPublishers.ofString(sb.toString())).build();
        HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString());
        return JsonParser.parseString(r.body()).getAsJsonObject();
    }

    // ---------------------------------------------------------------- polling

    private synchronized void startPolling() {
        if (poller != null) return;
        poller = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "NeonLyrics-Poll");
            t.setDaemon(true);
            return t;
        });
        poller.scheduleWithFixedDelay(() -> {
            try {
                poll();
            } catch (Exception e) {
                NeonLyricsClient.LOGGER.debug("Spotify poll failed: {}", e.toString());
            }
        }, 0, 2, TimeUnit.SECONDS);
    }

    public void pollSoon() {
        pool.submit(() -> {
            try {
                Thread.sleep(500);
                poll();
            } catch (Exception ignored) {
            }
        });
    }

    private void poll() throws Exception {
        if (manual) return;
        HttpResponse<String> r = call("GET", API + "/me/player/currently-playing", null);
        long now = System.nanoTime();
        if (r.statusCode() == 200 && !r.body().isBlank()) {
            JsonObject o = JsonParser.parseString(r.body()).getAsJsonObject();
            JsonElement item = o.get("item");
            if (item != null && item.isJsonObject()) {
                Track t = parseTrack(item.getAsJsonObject());
                boolean playing = o.has("is_playing") && o.get("is_playing").getAsBoolean();
                long progress = o.has("progress_ms") && !o.get("progress_ms").isJsonNull()
                        ? o.get("progress_ms").getAsLong() : 0;
                state = new PlaybackState(t, playing, progress, now);
                if (!t.id().equals(lastTrackId)) {
                    lastTrackId = t.id();
                    NeonLyricsClient.LYRICS.onTrack(t);
                }
                return;
            }
        }
        state = PlaybackState.NONE;
    }

    // ---------------------------------------------------------------- data

    public CompletableFuture<List<Track>> likedSongs() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<String> r = call("GET", API + "/me/tracks?limit=50", null);
                check(r);
                return parseTrackItems(JsonParser.parseString(r.body()).getAsJsonObject().getAsJsonArray("items"));
            } catch (Exception e) {
                throw wrap(e);
            }
        }, pool);
    }

    public record PlaylistInfo(String id, String uri, String name, int total) {
    }

    public CompletableFuture<List<PlaylistInfo>> playlists() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<String> r = call("GET", API + "/me/playlists?limit=50", null);
                check(r);
                List<PlaylistInfo> out = new ArrayList<>();
                for (JsonElement e : JsonParser.parseString(r.body()).getAsJsonObject().getAsJsonArray("items")) {
                    if (!e.isJsonObject()) continue;
                    JsonObject p = e.getAsJsonObject();
                    int total = 0;
                    if (p.has("tracks") && p.get("tracks").isJsonObject() && p.getAsJsonObject("tracks").has("total")) {
                        total = p.getAsJsonObject("tracks").get("total").getAsInt();
                    }
                    out.add(new PlaylistInfo(str(p, "id"), str(p, "uri"), str(p, "name"), total));
                }
                return out;
            } catch (Exception e) {
                throw wrap(e);
            }
        }, pool);
    }

    public CompletableFuture<List<Track>> playlistTracks(String playlistId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<String> r = call("GET", API + "/playlists/" + playlistId + "/items?limit=50", null);
                if (r.statusCode() == 404) {
                    r = call("GET", API + "/playlists/" + playlistId + "/tracks?limit=50", null);
                }
                if (r.statusCode() == 403) {
                    throw new IllegalStateException(
                            "Spotify only lets this app open playlists you created yourself (or shared with you to edit).");
                }
                check(r);
                return parseTrackItems(JsonParser.parseString(r.body()).getAsJsonObject().getAsJsonArray("items"));
            } catch (Exception e) {
                throw wrap(e);
            }
        }, pool);
    }

    public CompletableFuture<List<Track>> search(String query) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<String> r = call("GET",
                        API + "/search?type=track&limit=10&q=" + enc(query), null);
                check(r);
                JsonArray items = JsonParser.parseString(r.body()).getAsJsonObject()
                        .getAsJsonObject("tracks").getAsJsonArray("items");
                List<Track> out = new ArrayList<>();
                for (JsonElement e : items) {
                    if (e.isJsonObject()) out.add(parseTrack(e.getAsJsonObject()));
                }
                return out;
            } catch (Exception e) {
                throw wrap(e);
            }
        }, pool);
    }

    // ---------------------------------------------------------------- playback control

    /** Plays a list of tracks starting at {@code startIndex} (Spotify queues up to 50). */
    public CompletableFuture<Void> playTracks(List<Track> tracks, int startIndex) {
        manual = false;
        JsonObject body = new JsonObject();
        JsonArray uris = new JsonArray();
        for (int i = startIndex; i < tracks.size() && uris.size() < 50; i++) uris.add(tracks.get(i).uri());
        body.add("uris", uris);
        return command("PUT", "/me/player/play", body.toString());
    }

    public CompletableFuture<Void> playContext(String contextUri, String trackUri) {
        manual = false;
        JsonObject body = new JsonObject();
        body.addProperty("context_uri", contextUri);
        JsonObject off = new JsonObject();
        off.addProperty("uri", trackUri);
        body.add("offset", off);
        return command("PUT", "/me/player/play", body.toString());
    }

    public CompletableFuture<Void> togglePause() {
        return command("PUT", state.playing() ? "/me/player/pause" : "/me/player/play", null);
    }

    public CompletableFuture<Void> next() {
        return command("POST", "/me/player/next", null);
    }

    public CompletableFuture<Void> previous() {
        return command("POST", "/me/player/previous", null);
    }

    private CompletableFuture<Void> command(String method, String path, String body) {
        return CompletableFuture.runAsync(() -> {
            try {
                check(call(method, API + path, body));
                pollSoon();
            } catch (Exception e) {
                throw wrap(e);
            }
        }, pool);
    }

    // ---------------------------------------------------------------- helpers

    private HttpResponse<String> call(String method, String url, String body) throws Exception {
        refresh();
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url))
                .header("Authorization", "Bearer " + accessToken)
                .timeout(Duration.ofSeconds(10));
        if (body == null) {
            b.method(method, HttpRequest.BodyPublishers.noBody());
        } else {
            b.header("Content-Type", "application/json").method(method, HttpRequest.BodyPublishers.ofString(body));
        }
        return http.send(b.build(), HttpResponse.BodyHandlers.ofString());
    }

    private void check(HttpResponse<String> r) {
        int c = r.statusCode();
        if (c >= 200 && c < 300) return;
        String api = apiMessage(r);
        String low = api.toLowerCase();
        if (c == 404 && r.request().uri().getPath().contains("/me/player")) {
            throw new IllegalStateException("No active Spotify device. Open the Spotify app, play any song for a second, then try again.");
        }
        if (c == 401) throw new IllegalStateException("Spotify login expired. Settings > Misc > Unlink Spotify, then link again.");
        if (c == 403) {
            if (low.contains("premium")) {
                throw new IllegalStateException("Playing songs needs Spotify Premium on this account.");
            }
            if (low.contains("not registered") || low.contains("allowlist") || low.contains("dashboard")
                    || low.contains("user") || api.isEmpty()) {
                throw new IllegalStateException("Spotify blocked this account. In developer.spotify.com/dashboard open your app > "
                        + "User Management and add the email of the Spotify account you log in with. "
                        + "The app's owner also needs Premium. (Spotify said: " + (api.isEmpty() ? "403" : api) + ")");
            }
            throw new IllegalStateException("Spotify refused (403): " + api);
        }
        if (c == 429) throw new IllegalStateException("Spotify rate limit hit, try again in a moment.");
        throw new IllegalStateException("Spotify error " + c + (api.isEmpty() ? "" : ": " + api));
    }

    private static String apiMessage(HttpResponse<String> r) {
        try {
            JsonObject o = JsonParser.parseString(r.body()).getAsJsonObject();
            if (o.has("error") && o.get("error").isJsonObject()) {
                JsonObject e = o.getAsJsonObject("error");
                return str(e, "message");
            }
            if (o.has("error_description")) return str(o, "error_description");
            if (o.has("error")) return str(o, "error");
        } catch (Exception ignored) {
        }
        return "";
    }

    private static RuntimeException wrap(Exception e) {
        return e instanceof RuntimeException re ? re : new RuntimeException(e.getMessage(), e);
    }

    private List<Track> parseTrackItems(JsonArray items) {
        List<Track> out = new ArrayList<>();
        for (JsonElement e : items) {
            if (!e.isJsonObject()) continue;
            JsonObject it = e.getAsJsonObject();
            JsonElement t = it.has("track") ? it.get("track") : it.get("item");
            if (t != null && t.isJsonObject() && t.getAsJsonObject().has("uri")) {
                out.add(parseTrack(t.getAsJsonObject()));
            }
        }
        return out;
    }

    private static Track parseTrack(JsonObject t) {
        StringBuilder artists = new StringBuilder();
        if (t.has("artists") && t.get("artists").isJsonArray()) {
            for (JsonElement a : t.getAsJsonArray("artists")) {
                if (artists.length() > 0) artists.append(", ");
                artists.append(str(a.getAsJsonObject(), "name"));
            }
        }
        String album = t.has("album") && t.get("album").isJsonObject() ? str(t.getAsJsonObject("album"), "name") : "";
        long dur = t.has("duration_ms") && !t.get("duration_ms").isJsonNull() ? t.get("duration_ms").getAsLong() : 0;
        String id = t.has("id") && !t.get("id").isJsonNull() ? t.get("id").getAsString() : str(t, "uri");
        return new Track(id, str(t, "uri"), str(t, "name"), artists.toString(), album, dur);
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private static Map<String, String> parseQuery(String raw) {
        Map<String, String> m = new LinkedHashMap<>();
        if (raw == null) return m;
        for (String kv : raw.split("&")) {
            int i = kv.indexOf('=');
            if (i > 0) {
                m.put(URLDecoder.decode(kv.substring(0, i), StandardCharsets.UTF_8),
                        URLDecoder.decode(kv.substring(i + 1), StandardCharsets.UTF_8));
            }
        }
        return m;
    }
}
